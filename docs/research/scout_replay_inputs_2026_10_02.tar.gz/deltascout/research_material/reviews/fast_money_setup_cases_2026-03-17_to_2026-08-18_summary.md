# Fast Money Setup Cases Summary

scope: `2026-03-17_to_2026-08-18`
setup_cases: `246`

## Quality Classes

- `A_STRONG_IMPULSE`: 2
- `B_CLEAN_SCALP`: 26
- `C_BARELY_HIT`: 172
- `D_LATE_NO_EDGE`: 11
- `F_COUNTERTREND_SWEEP`: 35

## Repeatability Families

- `countertrend_stop_sweep`: 126
- `generic_pre_impulse`: 5
- `late_liquidity_chase`: 16
- `m2_density_pre_impulse`: 58
- `reject_supported_pre_impulse`: 2
- `reversal_forerunner`: 39

## Review Priority

- `borderline_review`: 172
- `candidate_family_review`: 26
- `countertrend_review`: 20
- `timing_filter_review`: 11
- `top_manual_review`: 17

## Top Manual Review Cases

- `2026-06-07_long_fmsc170` `2026-06-07 21:55:00` `long` `A_STRONG_IMPULSE` `reversal_forerunner` score=92.826667 mfe60=2623.8 t1000=19 adverse1000=7.7 priority=`top_manual_review`
- `2026-06-05_long_fmsc156` `2026-06-05 16:12:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=88.098933 mfe60=1736.3 t1000=3 adverse1000=74.6 priority=`top_manual_review`
- `2026-04-12_short_fmsc075` `2026-04-12 01:22:00` `short` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=85.982 mfe60=1771 t1000=15 adverse1000=0.6 priority=`top_manual_review`
- `2026-06-04_short_fmsc149` `2026-06-04 00:22:00` `short` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=85.876267 mfe60=1570.8 t1000=9 adverse1000=6.7 priority=`top_manual_review`
- `2026-06-25_long_fmsc202` `2026-06-25 14:32:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=85.368267 mfe60=1306.8 t1000=2 adverse1000=14.4 priority=`top_manual_review`
- `2026-06-11_long_fmsc182` `2026-06-11 17:27:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=85.259867 mfe60=1438.6 t1000=6 adverse1000=15.1 priority=`top_manual_review`
- `2026-03-30_long_fmsc045` `2026-03-30 00:17:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=84.7692 mfe60=1279.1 t1000=3 adverse1000=9.9 priority=`top_manual_review`
- `2026-06-06_long_fmsc167` `2026-06-06 05:15:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=83.355067 mfe60=1390.7 t1000=8 adverse1000=30 priority=`top_manual_review`
- `2026-07-06_short_fmsc229` `2026-07-06 11:56:00` `short` `B_CLEAN_SCALP` `reject_supported_pre_impulse` score=82.754 mfe60=1267 t1000=8 adverse1000=3.5 priority=`candidate_family_review`
- `2026-06-05_long_fmsc155` `2026-06-05 07:15:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=81.6432 mfe60=1621.1 t1000=19 adverse1000=26.8 priority=`top_manual_review`
- `2026-04-02_short_fmsc058` `2026-04-02 01:00:00` `short` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=81.114267 mfe60=1564.8 t1000=19 adverse1000=22.4 priority=`top_manual_review`
- `2026-06-04_long_fmsc147` `2026-06-04 13:28:00` `long` `B_CLEAN_SCALP` `reversal_forerunner` score=80.9404 mfe60=1279.2 t1000=11 adverse1000=24.8 priority=`candidate_family_review`
- `2026-04-17_long_fmsc091` `2026-04-17 13:32:00` `long` `A_STRONG_IMPULSE` `m2_density_pre_impulse` score=80.445467 mfe60=1622.4 t1000=20 adverse1000=50.7 priority=`top_manual_review`
- `2026-05-29_long_fmsc129` `2026-05-29 14:50:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=80.099467 mfe60=1459.4 t1000=20 adverse1000=2.4 priority=`top_manual_review`
- `2026-06-04_long_fmsc146` `2026-06-04 12:12:00` `long` `B_CLEAN_SCALP` `reversal_forerunner` score=79.7224 mfe60=1530.2 t1000=21 adverse1000=26.7 priority=`candidate_family_review`
- `2026-03-29_long_fmsc042` `2026-03-29 22:50:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=79.464133 mfe60=1340.9 t1000=11 adverse1000=91.3 priority=`top_manual_review`
- `2026-03-23_long_fmsc021` `2026-03-23 10:56:00` `long` `D_LATE_NO_EDGE` `reversal_forerunner` score=78.69 mfe60=2995.3 t1000=10 adverse1000=4.3 priority=`timing_filter_review`
- `2026-06-26_long_fmsc206` `2026-06-26 03:24:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=78.129867 mfe60=1453.6 t1000=24 adverse1000=9.4 priority=`top_manual_review`
- `2026-06-05_long_fmsc157` `2026-06-05 20:06:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=76.3044 mfe60=2081.2 t1000=4 adverse1000=0.1 priority=`top_manual_review`
- `2026-06-06_short_fmsc168` `2026-06-06 04:03:00` `short` `B_CLEAN_SCALP` `m2_density_pre_impulse` score=76.2452 mfe60=1372.1 t1000=25 adverse1000=24.1 priority=`candidate_family_review`

## Use

This table deduplicates pre-impulse proxy rows into one setup case per move cluster.
Use it to separate strong/repeatable impulses from barely-hit, late, failed, and countertrend cases before backtesting.
