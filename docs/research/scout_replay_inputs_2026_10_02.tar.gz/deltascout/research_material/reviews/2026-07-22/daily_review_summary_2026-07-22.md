# Daily Review Summary 2026-07-22

- processed_date: 2026-07-22
- accepted_row_count: 0
- reject_row_count: 17
- interesting_reject_row_count: 14
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-07-22.csv
- reject_reason_summary_group_count: 6
- reject_counts_by_reason:
  - 3of3_fail: 4
  - chop_coh: 3
  - direction_mismatch: 9
  - vwap_side: 1
- files_created:
  - accepted_event_context_2026-07-22.csv
  - reject_event_context_2026-07-22.csv
  - interesting_rejects_2026-07-22.csv
  - reject_reason_summary_2026-07-22.csv
  - daily_review_summary_2026-07-22.md
