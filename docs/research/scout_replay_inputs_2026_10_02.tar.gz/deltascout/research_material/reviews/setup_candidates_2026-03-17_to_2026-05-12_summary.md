# Setup Candidate Discovery Summary

scope: `2026-03-17_to_2026-05-12`
move_threshold_usd: `1000`
candidate_rows: `209`

## Source Counts

- `accepted_peak_lifecycle_reference`: 15
- `interesting_reject`: 8
- `m2_6_chain_candidate`: 182
- `reject_1000_hit`: 4

## Track Counts

- `current_peak_emit_reference`: 15
- `m2_6_late_no_edge_warning`: 5
- `m2_6_process_chain`: 177
- `rejected_family_followthrough`: 12

## Direction Counts

- `long`: 125
- `short`: 84

## Accepted Lifecycle Coverage

- `inferred_sl_missing_peak_link`: 5
- `manual_confirmed_sl_result`: 1
- `no_trade_missed_entry`: 1
- `plain_loss_stop`: 4
- `protected_profit_trailing_stop`: 2
- `user_confirmed_sl_tp1_without_artifact_join`: 1
- `user_confirmed_sl_without_artifact_join`: 1

## Top Priority Candidates

- `2026-03-23 10:51:00` `long` `m2_6_chain_candidate` `m2_6_process_chain` score=3204.9 dir60=1881.5 fav60=
- `2026-03-23 11:01:00` `long` `interesting_reject` `rejected_family_followthrough` score=2971.9 dir60=1441 fav60=2871.9
- `2026-03-23 10:12:00` `long` `m2_6_chain_candidate` `m2_6_late_no_edge_warning` score=2539.4 dir60=2339.4 fav60=
- `2026-03-23 10:29:00` `long` `m2_6_chain_candidate` `m2_6_late_no_edge_warning` score=2508 dir60=2308 fav60=
- `2026-03-21 23:02:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=2092.9 dir60=1892.9 fav60=
- `2026-03-21 23:46:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=2080.7 dir60=1080.7 fav60=
- `2026-03-21 23:03:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=2021.1 dir60=1821.1 fav60=
- `2026-04-07 22:33:00` `long` `m2_6_chain_candidate` `m2_6_process_chain` score=1989.8 dir60=1789.8 fav60=
- `2026-04-07 22:24:00` `long` `m2_6_chain_candidate` `m2_6_process_chain` score=1912.7 dir60=1712.7 fav60=
- `2026-03-21 23:47:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=1903.4 dir60=902.9 fav60=
- `2026-04-16 13:29:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=1837.9 dir60=1165.9 fav60=
- `2026-04-12 00:50:00` `short` `m2_6_chain_candidate` `m2_6_late_no_edge_warning` score=1813.6 dir60=1613.6 fav60=

## Use

This file is a research surface, not a live signal spec.
Promote a row family only after clustered repeatability, lifecycle fit, and entry timing are reviewed.
