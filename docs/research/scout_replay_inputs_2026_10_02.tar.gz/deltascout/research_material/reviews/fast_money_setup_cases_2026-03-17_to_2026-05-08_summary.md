# Fast Money Setup Cases Summary

scope: `2026-03-17_to_2026-05-08`
setup_cases: `109`

## Quality Classes

- `A_STRONG_IMPULSE`: 1
- `B_CLEAN_SCALP`: 6
- `C_BARELY_HIT`: 79
- `D_LATE_NO_EDGE`: 7
- `F_COUNTERTREND_SWEEP`: 16

## Repeatability Families

- `countertrend_stop_sweep`: 57
- `generic_pre_impulse`: 2
- `late_liquidity_chase`: 7
- `m2_density_pre_impulse`: 20
- `reversal_forerunner`: 23

## Review Priority

- `borderline_review`: 79
- `candidate_family_review`: 6
- `countertrend_review`: 10
- `timing_filter_review`: 7
- `top_manual_review`: 7

## Top Manual Review Cases

- `2026-04-12_short_fmsc075` `2026-04-12 01:22:00` `short` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=85.982 mfe60=1771 t1000=15 adverse1000=0.6 priority=`top_manual_review`
- `2026-03-30_long_fmsc045` `2026-03-30 00:17:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=84.7692 mfe60=1279.1 t1000=3 adverse1000=9.9 priority=`top_manual_review`
- `2026-04-02_short_fmsc058` `2026-04-02 01:00:00` `short` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=81.114267 mfe60=1564.8 t1000=19 adverse1000=22.4 priority=`top_manual_review`
- `2026-04-17_long_fmsc091` `2026-04-17 13:32:00` `long` `A_STRONG_IMPULSE` `m2_density_pre_impulse` score=80.445467 mfe60=1622.4 t1000=20 adverse1000=50.7 priority=`top_manual_review`
- `2026-03-29_long_fmsc042` `2026-03-29 22:50:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=79.464133 mfe60=1340.9 t1000=11 adverse1000=91.3 priority=`top_manual_review`
- `2026-03-23_long_fmsc021` `2026-03-23 10:56:00` `long` `D_LATE_NO_EDGE` `reversal_forerunner` score=78.69 mfe60=2995.3 t1000=10 adverse1000=4.3 priority=`timing_filter_review`
- `2026-04-17_long_fmsc090` `2026-04-17 12:44:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=76.012133 mfe60=1324.9 t1000=26 adverse1000=1.6 priority=`top_manual_review`
- `2026-04-23_short_fmsc108` `2026-04-23 09:43:00` `short` `B_CLEAN_SCALP` `m2_density_pre_impulse` score=75.723067 mfe60=1214.7 t1000=23 adverse1000=8.1 priority=`candidate_family_review`
- `2026-03-21_short_fmsc017` `2026-03-21 23:43:00` `short` `D_LATE_NO_EDGE` `late_liquidity_chase` score=72.480667 mfe60=1979.5 t1000=10 adverse1000=3.2 priority=`timing_filter_review`
- `2026-03-26_long_fmsc035` `2026-03-26 20:09:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=71.401867 mfe60=1053 t1000=4 adverse1000=10.4 priority=`top_manual_review`
- `2026-03-31_long_fmsc052` `2026-03-31 17:07:00` `long` `C_BARELY_HIT` `reversal_forerunner` score=68.6148 mfe60=1035.4 t1000=9 adverse1000=31.8 priority=`borderline_review`
- `2026-03-31_short_fmsc054` `2026-03-31 14:34:00` `short` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=67.546133 mfe60=1191.9 t1000=18 adverse1000=7.7 priority=`countertrend_review`
- `2026-03-29_short_fmsc044` `2026-03-29 22:39:00` `short` `D_LATE_NO_EDGE` `late_liquidity_chase` score=65.919467 mfe60=1321.9 t1000=7 adverse1000=0.8 priority=`timing_filter_review`
- `2026-03-23_short_fmsc026` `2026-03-23 11:41:00` `short` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=65.443467 mfe60=1145.9 t1000=21 adverse1000=7 priority=`countertrend_review`
- `2026-04-19_short_fmsc096` `2026-04-19 21:46:00` `short` `C_BARELY_HIT` `generic_pre_impulse` score=65.402267 mfe60=1051.3 t1000=19 adverse1000=8.9 priority=`borderline_review`
- `2026-03-31_long_fmsc051` `2026-03-31 16:59:00` `long` `C_BARELY_HIT` `reversal_forerunner` score=65.2236 mfe60=1035.3 t1000=17 adverse1000=33.5 priority=`borderline_review`
- `2026-04-07_long_fmsc064` `2026-04-07 20:55:00` `long` `C_BARELY_HIT` `m2_density_pre_impulse` score=65.201867 mfe60=1044.6 t1000=18 adverse1000=25 priority=`borderline_review`
- `2026-04-21_short_fmsc100` `2026-04-21 14:46:00` `short` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=65.184667 mfe60=1064 t1000=19 adverse1000=20 priority=`countertrend_review`
- `2026-04-21_short_fmsc102` `2026-04-21 19:26:00` `short` `C_BARELY_HIT` `m2_density_pre_impulse` score=65.137867 mfe60=1072.6 t1000=17 adverse1000=49.5 priority=`borderline_review`
- `2026-03-24_long_fmsc030` `2026-03-24 20:08:00` `long` `F_COUNTERTREND_SWEEP` `countertrend_stop_sweep` score=64.8568 mfe60=1003.9 t1000=19 adverse1000=8.2 priority=`countertrend_review`

## Use

This table deduplicates pre-impulse proxy rows into one setup case per move cluster.
Use it to separate strong/repeatable impulses from barely-hit, late, failed, and countertrend cases before backtesting.
