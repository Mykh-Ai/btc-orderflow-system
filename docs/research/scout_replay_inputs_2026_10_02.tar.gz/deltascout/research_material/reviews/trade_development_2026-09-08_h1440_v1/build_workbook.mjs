import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const reviewRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(reviewRoot, "../../../..");
const outputDir = path.join(repoRoot, "outputs/01a07785-f5ae-71b2-bd60-b0c48f8c8036");
const analysis = JSON.parse(await fs.readFile(path.join(reviewRoot, "analysis.json"), "utf8"));
const manifest = JSON.parse(await fs.readFile(path.join(reviewRoot, "development_manifest.json"), "utf8"));

const num = (value) => {
  if (value === null || value === undefined || value === "") return null;
  const result = Number(value);
  return Number.isFinite(result) ? result : null;
};
const bool = (value) => value === true || value === "True" || value === "true";
const fmt = (value, digits = 3) => value === null || value === undefined ? "n.a." : Number(value).toFixed(digits);

const horizonRows = analysis.summaries.filter((r) => r.cohort === "ab_portfolio" && r.lifecycle === "ALL")
  .sort((a, b) => a.horizon_min - b.horizon_min);
const lifecycleRows = analysis.summaries.filter((r) => r.cohort === "ab_portfolio" && ["PLAIN_SL", "TP1_SL", "TP1_TP2_TRAILING_STOP"].includes(r.lifecycle) && [240, 1440].includes(Number(r.horizon_min)))
  .sort((a, b) => Number(a.horizon_min) - Number(b.horizon_min) || a.lifecycle.localeCompare(b.lifecycle));
const comparisonRows = analysis.summaries.filter((r) => r.lifecycle === "ALL" && [240, 1440].includes(Number(r.horizon_min)))
  .sort((a, b) => Number(a.horizon_min) - Number(b.horizon_min) || a.cohort.localeCompare(b.cohort));

const cohortLabels = {
  all_independent: "Без A/B · окремі можливості",
  all_portfolio: "Без A/B · одна позиція",
  ab_independent: "З A/B · окремі можливості",
  ab_portfolio: "З A/B · одна позиція",
};
const lifecycleLabels = {
  PLAIN_SL: "PLAIN_SL",
  TP1_SL: "TP1 → SL",
  TP1_TP2_TRAILING_STOP: "TP2 → trailing",
};

const wb = Workbook.create();
const summary = wb.worksheets.add("Summary");
const checkpoints = wb.worksheets.add("Checkpoints");
const cohorts = wb.worksheets.add("Cohort summary");
const method = wb.worksheets.add("Methodology");
for (const sheet of [summary, checkpoints, cohorts, method]) {
  sheet.showGridLines = false;
}

function colLetter(index) {
  let n = index + 1;
  let out = "";
  while (n > 0) {
    const rem = (n - 1) % 26;
    out = String.fromCharCode(65 + rem) + out;
    n = Math.floor((n - 1) / 26);
  }
  return out;
}

function putTable(sheet, startRow, startCol, headers, rows, tableName) {
  const matrix = [headers, ...rows];
  const endRow = startRow + matrix.length - 1;
  const endCol = startCol + headers.length - 1;
  const address = `${colLetter(startCol)}${startRow}:${colLetter(endCol)}${endRow}`;
  sheet.getRange(address).values = matrix;
  const header = sheet.getRange(`${colLetter(startCol)}${startRow}:${colLetter(endCol)}${startRow}`);
  header.format = { fill: "#1F4E78", font: { name: "Arial", size: 10, bold: true, color: "#FFFFFF" }, horizontalAlignment: "center", verticalAlignment: "center" };
  sheet.getRange(`${colLetter(startCol)}${startRow + 1}:${colLetter(endCol)}${endRow}`).format = { font: { name: "Arial", size: 10, color: "#222222" }, verticalAlignment: "center" };
  sheet.getRange(address).format.borders = { preset: "outside", style: "thin", color: "#B7C9D6" };
  if (tableName) sheet.tables.add(address, true, tableName);
  return address;
}

summary.getRange("A1").values = [["Trade development checkpoints"]];
summary.getRange("A2").values = [["Corrected V8 replay · completed-minute clock · horizons 5, 15, 30, 60, 240 and 1440 minutes"]];
summary.getRange("A1:Q1").format = { font: { name: "Arial", size: 16, bold: true, color: "#1F2937" } };
summary.getRange("A2:Q2").format = { font: { name: "Arial", size: 10, italic: true, color: "#4B5563" } };
summary.getRange("A4").values = [["A/B portfolio · all lifecycle states"]];
summary.getRange("A4:H4").format = { fill: "#D9EAF7", font: { name: "Arial", size: 11, bold: true, color: "#1F2937" } };
putTable(summary, 5, 0,
  ["Horizon (min)", "Trades", "Open at checkpoint", "Market complete", "Reference complete", "TP1 done", "Median market price (R)", "Median market MFE (R)", "Median market MAE (R)", "Median position net if closed (R)", "Median directional delta (%)", "Supportive flow, no progress", "Structure adverse"],
  horizonRows.map((r) => [Number(r.horizon_min), Number(r.trade_count), Number(r.open_count), Number(r.market_complete_count), Number(r.reference_complete_count), Number(r.tp1_done_count), num(r.median_market_price_r), num(r.median_market_mfe_r), num(r.median_market_mae_r), num(r.median_position_net_r), num(r.median_directional_delta_pct) * 100, Number(r.supportive_no_progress_count), Number(r.structure_adverse_count)]),
  "ABPortfolioHorizons");
summary.getRange("G6:J11").format.numberFormat = "0.000";
summary.getRange("K6:K11").format.numberFormat = "0.0";

summary.getRange("A14").values = [["A/B portfolio · lifecycle comparison at 4 hours and 1 day"]];
summary.getRange("A14:H14").format = { fill: "#D9EAF7", font: { name: "Arial", size: 11, bold: true, color: "#1F2937" } };
putTable(summary, 15, 0,
  ["Lifecycle", "Horizon (min)", "Trades", "Open", "TP1 done", "Market MFE (R)", "Market MAE (R)", "Position net if closed (R)", "Median delta (%)", "Structure adverse", "Median time to TP1 (min)"],
  lifecycleRows.map((r) => [lifecycleLabels[r.lifecycle] || r.lifecycle, Number(r.horizon_min), Number(r.trade_count), Number(r.open_count), Number(r.tp1_done_count), num(r.median_market_mfe_r), num(r.median_market_mae_r), num(r.median_position_net_r), num(r.median_directional_delta_pct) * 100, Number(r.structure_adverse_count), num(r.median_label_time_to_tp1_min)]),
  "ABPortfolioLifecycle");
summary.getRange("F16:H21").format.numberFormat = "0.000";
summary.getRange("I16:I21").format.numberFormat = "0.0";
summary.getRange("K16:K21").format.numberFormat = "0.0";

summary.getRange("A24").values = [["Cohort comparison · all lifecycle states"]];
summary.getRange("A24:H24").format = { fill: "#D9EAF7", font: { name: "Arial", size: 11, bold: true, color: "#1F2937" } };
putTable(summary, 25, 0,
  ["Cohort", "Horizon (min)", "Trades", "Market complete", "Reference complete", "TP1 done", "Median market MFE (R)", "Median market MAE (R)", "Median position net (R)", "Supportive flow, no progress"],
  comparisonRows.map((r) => [cohortLabels[r.cohort] || r.cohort, Number(r.horizon_min), Number(r.trade_count), Number(r.market_complete_count), Number(r.reference_complete_count), Number(r.tp1_done_count), num(r.median_market_mfe_r), num(r.median_market_mae_r), num(r.median_position_net_r), Number(r.supportive_no_progress_count)]),
  "CohortComparison");
summary.getRange("G26:I33").format.numberFormat = "0.000";

summary.getRange("A36").values = [["Reading notes"]];
summary.getRange("A36:H36").format = { fill: "#D9EAF7", font: { name: "Arial", size: 11, bold: true, color: "#1F2937" } };
summary.getRange("A37:F42").values = [
  ["Position net if closed", "Realized legs + mark-to-market remaining size − incurred costs − estimated exit cost for remaining size."],
  ["Market MFE / MAE", "Price excursion over the horizon. Entry-bar wicks are excluded because the modeled fill may occur after them."],
  ["Position MFE / MAE", "Lower bound while the position was open. Exit-bar wicks are excluded; executed leg prices are included."],
  ["Flow response", "Signed reference-feed delta is compared with signed reference price movement. Missing or synthetic windows remain unavailable."],
  ["Structure adverse", "Reference close is beyond the frozen initial swing level against the trade direction at the checkpoint."],
  ["Completeness", `264 checkpoints across ${manifest.candidate_count} candidates. Missing market windows: ${manifest.missing_market_windows}; missing reference windows: ${manifest.missing_reference_windows}.`],
];
summary.getRange("A37:A42").format = { font: { name: "Arial", size: 10, bold: true, color: "#1F2937" } };
summary.getRange("B37:F42").format = { font: { name: "Arial", size: 10, color: "#374151" }, wrapText: true };

const checkpointHeaders = ["Cohort: no filter independent", "Cohort: no filter portfolio", "Cohort: A/B independent", "Cohort: A/B portfolio", "Candidate ID", "Trade ID", "Side", "Horizon (min)", "Checkpoint UTC", "State", "Remaining qty", "Entry USDC", "Initial SL USDC", "Risk USDC", "Market complete", "Reference complete", "Observed market minutes", "Observed reference minutes", "Market close USDC", "Market price (R)", "Market MFE (R)", "Market MAE (R)", "Position MFE lower bound (R)", "Position MAE lower bound (R)", "Position net if closed (USDC)", "Position net if closed (R)", "Delta (%)", "Flow response", "Structure adverse", "Structure breached", "TP1 done", "Label lifecycle", "Label time to TP1 (min)", "Label holding (min)", "Label final net USDC", "Reference quality classes"];
const checkpointRows = analysis.checkpoints.sort((a, b) => a.candidate_id.localeCompare(b.candidate_id) || Number(a.horizon_min) - Number(b.horizon_min)).map((r) => [
  bool(r.all_independent), bool(r.all_portfolio), bool(r.ab_independent), bool(r.ab_portfolio), r.candidate_id, r.trade_id, r.side, Number(r.horizon_min), r.checkpoint_ts_utc, r.state_at_checkpoint, num(r.remaining_qty), num(r.entry_price_usdc), num(r.initial_stop_usdc), num(r.risk_price_usdc), bool(r.market_complete), bool(r.reference_complete), Number(r.market_minutes_observed), Number(r.reference_minutes_observed), num(r.market_close_usdc), num(r.market_price_r), num(r.market_mfe_r), num(r.market_mae_r), num(r.position_mfe_lower_bound_r), num(r.position_mae_lower_bound_r), num(r.position_net_if_closed_now_usdc), num(r.position_net_if_closed_now_r), num(r.directional_delta_pct) * 100, r.flow_price_response, r.structure_adverse_at_checkpoint === null ? "n.a." : bool(r.structure_adverse_at_checkpoint), r.structure_breached_by_checkpoint === null ? "n.a." : bool(r.structure_breached_by_checkpoint), bool(r.tp1_done_by_checkpoint), lifecycleLabels[r.label_lifecycle] || r.label_lifecycle, num(r.label_time_to_tp1_min), num(r.label_holding_min), num(r.label_final_net_usdc), r.reference_quality_classes,
]);
checkpoints.getRange("A1").values = [["Trade checkpoints by candidate and horizon"]];
checkpoints.getRange("A2").values = [["Flags identify membership in the four cohorts. `n.a.` means the required window was incomplete or unavailable."]];
checkpoints.getRange("A1:AJ1").format = { font: { name: "Arial", size: 14, bold: true, color: "#1F2937" } };
checkpoints.getRange("A2:AJ2").format = { font: { name: "Arial", size: 10, italic: true, color: "#4B5563" } };
putTable(checkpoints, 4, 0, checkpointHeaders, checkpointRows, "TradeCheckpoints");
checkpoints.getRange("K5:Z268").format.numberFormat = "0.000";
checkpoints.getRange("AA5:AA268").format.numberFormat = "0.0";
checkpoints.getRange("AG5:AI268").format.numberFormat = "0.0";
checkpoints.freezePanes.freezeRows(4);

const cohortHeaders = ["Cohort", "Lifecycle", "Horizon (min)", "Trades", "Open", "Market complete", "Reference complete", "TP1 done", "Median market price (R)", "Median market MFE (R)", "Median market MAE (R)", "Median position net (R)", "Median delta (%)", "Supportive flow, no progress", "Structure adverse", "Median time to TP1 (min)"];
const cohortRows = analysis.summaries.sort((a, b) => a.cohort.localeCompare(b.cohort) || Number(a.horizon_min) - Number(b.horizon_min) || a.lifecycle.localeCompare(b.lifecycle)).map((r) => [cohortLabels[r.cohort] || r.cohort, r.lifecycle === "ALL" ? "ALL" : lifecycleLabels[r.lifecycle] || r.lifecycle, Number(r.horizon_min), Number(r.trade_count), Number(r.open_count), Number(r.market_complete_count), Number(r.reference_complete_count), Number(r.tp1_done_count), num(r.median_market_price_r), num(r.median_market_mfe_r), num(r.median_market_mae_r), num(r.median_position_net_r), num(r.median_directional_delta_pct) * 100, Number(r.supportive_no_progress_count), Number(r.structure_adverse_count), num(r.median_label_time_to_tp1_min)]);
cohorts.getRange("A1").values = [["Cohort summary across all horizons"]];
cohorts.getRange("A2").values = [["The summary separates early path quality from the terminal trade label. Horizon rows do not change the replayed exit."]];
cohorts.getRange("A1:P1").format = { font: { name: "Arial", size: 14, bold: true, color: "#1F2937" } };
cohorts.getRange("A2:P2").format = { font: { name: "Arial", size: 10, italic: true, color: "#4B5563" } };
putTable(cohorts, 4, 0, cohortHeaders, cohortRows, "CohortSummary");
cohorts.getRange("I5:L100").format.numberFormat = "0.000";
cohorts.getRange("M5:M100").format.numberFormat = "0.0";
cohorts.getRange("P5:P100").format.numberFormat = "0.0";
cohorts.freezePanes.freezeRows(4);

method.getRange("A1").values = [["Methodology and provenance"]];
method.getRange("A1:F1").format = { font: { name: "Arial", size: 14, bold: true, color: "#1F2937" } };
const methodRows = [
  ["Scope", "Corrected V8 replay outputs, independent and one-position portfolio cohorts, 5/15/30/60/240/1440 minute checkpoints."],
  ["Anchor", manifest.anchor],
  ["Risk", manifest.risk_definition],
  ["Excursions", manifest.excursion_definition],
  ["Market source", "Official BTCUSDC Spot 1m feed. Open timestamps are shifted one minute in memory to completed-minute availability labels."],
  ["Reference source", "Clock-corrected BTCUSDT enriched effective feed with recovery quality sidecar."],
  ["Flow", "Signed buy/sell delta and signed reference price return over the checkpoint window. Synthetic, incomplete or missing reference windows are unavailable."],
  ["Structure", "Frozen initial swing price from the replay trade, evaluated with reference-feed closes."],
  ["Costs", "The checkpoint table carries incurred commission/slippage and estimates exit costs only for an open remainder."],
  ["Terminal labels", "`label_lifecycle`, `label_time_to_tp1_min`, `label_holding_min` and `label_final_net_usdc` are replay outcomes. They are not used to calculate earlier checkpoints."],
  ["Missingness", `Market windows unavailable: ${manifest.missing_market_windows}. Reference windows unavailable: ${manifest.missing_reference_windows}. No missing value is converted to zero.`],
  ["Sources", manifest.sources.map((s) => s.path).join("\n")],
  ["Generated", manifest.generated_at_utc],
];
putTable(method, 3, 0, ["Item", "Definition / source"], methodRows, "MethodologyTable");
method.getRange("B4:B16").format = { font: { name: "Arial", size: 10, color: "#374151" }, wrapText: true };
method.getRange("A4:A16").format = { font: { name: "Arial", size: 10, bold: true, color: "#1F2937" } };

for (const sheet of [summary, checkpoints, cohorts, method]) {
  const used = sheet.getUsedRange();
  used.format.font = { name: "Arial", size: 10 };
  used.format.verticalAlignment = "center";
  used.format.autofitColumns();
}
summary.getRange("A1:Q42").format.columnWidth = 15;
summary.getRange("A1:A42").format.columnWidth = 28;
summary.getRange("B1:B42").format.columnWidth = 60;
summary.getRange("C1:C42").format.columnWidth = 18;
summary.getRange("D1:F42").format.columnWidth = 16;
summary.getRange("G1:I42").format.columnWidth = 20;
summary.getRange("J1:J42").format.columnWidth = 25;
summary.getRange("K1:M42").format.columnWidth = 20;
summary.getRange("B37:B42").format.columnWidth = 60;
summary.getRange("A37:B42").format.rowHeight = 45;
checkpoints.getRange("A1:AJ268").format.columnWidth = 14;
checkpoints.getRange("E1:J268").format.columnWidth = 21;
checkpoints.getRange("AJ1:AJ268").format.columnWidth = 28;
cohorts.getRange("A1:P100").format.columnWidth = 16;
method.getRange("A1:A16").format.columnWidth = 20;
method.getRange("B1:F16").format.columnWidth = 46;

wb.recalculate();
const inspectSummary = await wb.inspect({ kind: "table", sheetId: "Summary", range: "A1:M33", include: "values,formulas", tableMaxRows: 40, tableMaxCols: 14, maxChars: 12000 });
const inspectErrors = await wb.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!", options: { useRegex: true, maxResults: 100 }, summary: "final formula error scan" });
await fs.mkdir(outputDir, { recursive: true });
await fs.writeFile(path.join(outputDir, "inspect_summary.ndjson"), inspectSummary.ndjson || "", "utf8");
await fs.writeFile(path.join(outputDir, "inspect_errors.ndjson"), inspectErrors.ndjson || "", "utf8");
const preview = await wb.render({ sheetName: "Summary", range: "A1:M42", scale: 1, format: "png" });
await fs.writeFile(path.join(outputDir, "summary_preview.png"), new Uint8Array(await preview.arrayBuffer()));
const xlsx = await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(path.join(outputDir, "trade_development_2026-09-08_h1440_v1.xlsx"));
console.log(JSON.stringify({ output: path.join(outputDir, "trade_development_2026-09-08_h1440_v1.xlsx"), preview: path.join(outputDir, "summary_preview.png"), inspectErrors: inspectErrors.ndjson || "" }, null, 2));
