# Daily Review Summary 2026-08-08

- processed_date: 2026-08-08
- accepted_row_count: 1
- reject_row_count: 15
- interesting_reject_row_count: 8
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-08-08.csv
- reject_reason_summary_group_count: 5
- reject_counts_by_reason:
  - 3of3_fail: 2
  - direction_mismatch: 8
  - vwap_side: 5
- files_created:
  - accepted_event_context_2026-08-08.csv
  - reject_event_context_2026-08-08.csv
  - interesting_rejects_2026-08-08.csv
  - reject_reason_summary_2026-08-08.csv
  - daily_review_summary_2026-08-08.md
