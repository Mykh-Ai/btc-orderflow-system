# Daily Review Summary 2026-06-26

- processed_date: 2026-06-26
- accepted_row_count: 1
- reject_row_count: 19
- interesting_reject_row_count: 13
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-06-26.csv
- reject_reason_summary_group_count: 6
- reject_counts_by_reason:
  - 3of3_fail: 4
  - chop_coh: 3
  - direction_mismatch: 10
  - vwap_side: 2
- files_created:
  - accepted_event_context_2026-06-26.csv
  - reject_event_context_2026-06-26.csv
  - interesting_rejects_2026-06-26.csv
  - reject_reason_summary_2026-06-26.csv
  - daily_review_summary_2026-06-26.md
