# Losing Trade Commonality Review

## Scope and outcome contract

- Known plain losses: **18** (16 canonical + 2 user-confirmed).
- Protected-profit controls with comparable signal joins: **7** of **8** (`TP1 + TP2 + trailing`).
- TP1-then-stop cases kept separate: **11**.
- Operator test trades excluded: **2** (`EX_EN_1779805524, EX_EN_1779900918`).
- Every market feature is pre-entry/cutoff-safe. Final outcome is used only as the cohort label.
- Timestamp contract: DeltaScout events are Europe/Bratislava local-naive; effective feed rows are UTC-naive and are joined only after conversion to UTC.

## Pattern prevalence: losses versus protected-profit controls

| Pattern | Plain losses | TP1→stop | Protected controls | Loss−protected | Fisher p (exploratory) |
|---|---:|---:|---:|---:|---:|
| open interest fell over the pre-entry 60m window | 10/17 (59%) | 3/9 (33%) | 2/7 (29%) | +30 pp | 0.371 |
| price moved with the trade direction while OI fell over 60m | 10/17 (59%) | 3/9 (33%) | 2/7 (29%) | +30 pp | 0.371 |
| current same-side delta-candidate percentile at or below 50 | 4/18 (22%) | 1/11 (9%) | 0/7 (0%) | +22 pp | 0.294 |
| 24h cumulative delta opposed the trade direction | 5/18 (28%) | 3/11 (27%) | 1/7 (14%) | +13 pp | 0.637 |
| POC remained ahead of the entry in the trade direction | 4/18 (22%) | 2/11 (18%) | 1/7 (14%) | +8 pp | 1.000 |
| open interest fell over the pre-entry 240m window | 11/17 (65%) | 2/9 (22%) | 4/7 (57%) | +8 pp | 1.000 |
| absolute VWAP extension at least 0.50% | 14/18 (78%) | 9/11 (82%) | 5/7 (71%) | +6 pp | 1.000 |
| entry within 0.25% of the directional 240m extreme | 16/18 (89%) | 9/11 (82%) | 6/7 (86%) | +3 pp | 1.000 |
| at least one earlier same-side delta candidate existed in the prior 240m | 18/18 (100%) | 11/11 (100%) | 7/7 (100%) | +0 pp | 1.000 |
| entry within 0.15% of the directional 60m extreme | 17/18 (94%) | 8/11 (73%) | 7/7 (100%) | -6 pp | 1.000 |
| 60m directional move plus entry near the 60m extreme | 17/18 (94%) | 7/11 (64%) | 7/7 (100%) | -6 pp | 1.000 |
| funding sign was crowded in the trade direction | 10/17 (59%) | 7/9 (78%) | 5/7 (71%) | -13 pp | 0.669 |
| 60m buy/sell delta opposed the trade direction | 0/18 (0%) | 1/11 (9%) | 1/7 (14%) | -14 pp | 0.280 |

## Descriptive loss families

The families below are mutually exclusive and assigned in this priority order: trusted 240m OI decline, OI-quality gap, broad-delta conflict, weak candidate, momentum chase, short-horizon counterflow, unresolved.

| Diagnostic family | Count | Share of known losses |
|---|---:|---:|
| `deleveraging_or_missing_position_build_240m` | 11 | 61% |
| `broad_delta_conflict` | 3 | 17% |
| `late_momentum_chase` | 2 | 11% |
| `oi_quality_gap` | 1 | 6% |
| `unresolved_other` | 1 | 6% |

## Numeric medians

| Feature | Plain loss | Protected | TP1→stop |
|---|---:|---:|---:|
| `abs_delta` | 53.06 | 63.17 | 66.58 |
| `imbalance` | 0.63 | 0.59 | 0.62 |
| `vwap_extension_abs_pct` | 0.79 | 0.89 | 0.86 |
| `peak_delta_percentile_24h` | 75.64 | 77.78 | 75.00 |
| `directional_extreme_distance_60m_pct` | 0.10 | 0.06 | 0.10 |
| `directional_extreme_distance_240m_pct` | 0.11 | 0.07 | 0.15 |
| `oi_change_60m` | -109.54 | 118.20 | 112.94 |
| `oi_change_240m` | -327.12 | -154.81 | 306.50 |
| `directional_delta_240m` | 524.73 | 919.48 | 1239.35 |
| `directional_delta_pct_240m` | 0.05 | 0.08 | 0.07 |
| `flow_concentration_15_240` | 0.66 | 0.56 | 0.44 |
| `flow_concentration_60_240` | 1.00 | 0.66 | 0.50 |
| `delta_efficiency_acceleration_15_240` | 4.01 | 2.66 | 3.31 |
| `ret_60m_pct_feed` | 0.13 | 0.23 | -0.35 |
| `duration_minutes` | 326.13 | 871.75 | 741.72 |

## Strongest loss pattern pairs

| Pair | Plain losses | Protected controls | Difference |
|---|---:|---:|---:|
| `vwap_extension_ge_0_5pct + oi_down_60m` | 8/17 (47%) | 1/7 (14%) | +33 pp |
| `vwap_extension_ge_0_5pct + directional_move_with_oi_down_60m` | 8/17 (47%) | 1/7 (14%) | +33 pp |
| `near_60m_extreme + oi_down_60m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `near_60m_extreme + directional_move_with_oi_down_60m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `oi_down_60m + oi_down_240m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `oi_down_60m + directional_move_with_oi_down_60m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `oi_down_60m + momentum_chase_60m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `oi_down_60m + prior_same_side_peak_240m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `oi_down_240m + directional_move_with_oi_down_60m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `directional_move_with_oi_down_60m + momentum_chase_60m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `directional_move_with_oi_down_60m + prior_same_side_peak_240m` | 10/17 (59%) | 2/7 (29%) | +30 pp |
| `near_240m_extreme + oi_down_60m` | 9/17 (53%) | 2/7 (29%) | +24 pp |

## LLM-judged subcohort

| Outcome group | Judged trades | Verdict counts | Repeated risk themes |
|---|---:|---|---|
| `plain_loss_stop` | 8 | REJECT=3, SUPPORT=5 | broader_context_conflict=2, late_or_extended_entry=7, nearby_level_or_liquidity=8, oi_unwind_or_covering=3, weak_or_moderate_peak=1 |
| `protected_profit_trailing_stop` | 5 | REJECT=1, SUPPORT=2, UNCLEAR=2 | broader_context_conflict=5, late_or_extended_entry=4, nearby_level_or_liquidity=5, oi_unwind_or_covering=1 |
| `tp1_then_stop` | 4 | SUPPORT=3, UNCLEAR=1 | broader_context_conflict=2, late_or_extended_entry=3, nearby_level_or_liquidity=4, oi_unwind_or_covering=1 |

## Shadow-policy decision

- Do **not** use `oi_change_240m < 0` as a live veto or automatic penalty. After correcting the local-to-UTC feed join it appears in 11/17 (65%) plain losses and 4/7 (57%) protected controls (exploratory Fisher p=1.000).
- `oi_change_60m < 0` remains a shadow-only candidate: 10/17 (59%) losses versus 2/7 (29%) protected controls, but the current sample is not decisive (p=0.371).
- Latest protected trade `EX_EN_1787063409` is a direct counterexample: OI Δ15=-404.51, Δ60=-749.92, Δ240=-725.78, while its lifecycle reached TP1, TP2 and trailing protection.
- Implementation target: journal the OI windows and a descriptive participation label, then calibrate prospectively against outcomes. Keep it out of order admission until enough shadow observations establish incremental value beyond the existing LLM verdict.

## Per-loss audit table

| Signal local | Side | Provenance | Δ | Imb | VWAP ext % | 60m extreme dist % | OI Δ60 | Peak pctile | LLM | Active patterns |
|---|---|---|---:|---:|---:|---:|---:|---:|---|---|
| 2026-03-20 00:40:00 | short | `canonical_trade_outcome` | -26.70 | 0.591 | 0.385 | 0.022 | -109.54 | 25.00 |  | near_60m_extreme, near_240m_extreme, weak_or_mid_peak_percentile, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, poc_ahead, prior_same_side_peak_240m, crowded_funding |
| 2026-03-29 19:23:00 | short | `canonical_trade_outcome` | -34.23 | 0.551 | 0.680 | 0.124 | 89.97 | 53.85 |  | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, momentum_chase_60m, prior_same_side_peak_240m |
| 2026-04-04 23:56:00 | long | `canonical_trade_outcome` | 26.64 | 0.578 | 0.575 | 0.120 | -163.75 | 22.22 |  | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, weak_or_mid_peak_percentile, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, prior_same_side_peak_240m, crowded_funding |
| 2026-04-05 14:34:00 | short | `manual_confirmed_sl_result` | -20.40 | 0.615 | 0.516 | 0.018 | 190.12 | 36.36 |  | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, weak_or_mid_peak_percentile, broad_delta_conflict_24h, momentum_chase_60m, prior_same_side_peak_240m, crowded_funding |
| 2026-04-11 15:11:00 | short | `user_confirmed_sl_without_artifact_join` | -53.59 | 0.604 | 0.264 | 0.107 | 622.60 | 84.62 |  | near_60m_extreme, near_240m_extreme, broad_delta_conflict_24h, momentum_chase_60m, prior_same_side_peak_240m, crowded_funding |
| 2026-04-21 10:48:00 | long | `canonical_trade_outcome` | 155.04 | 0.597 | 1.284 | 0.327 | 313.69 | 100.00 |  | vwap_extension_ge_0_5pct, prior_same_side_peak_240m |
| 2026-04-23 10:45:00 | short | `canonical_trade_outcome` | -48.36 | 0.631 | 0.897 | 0.031 | -505.52 | 60.00 |  | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, broad_delta_conflict_24h, momentum_chase_60m, prior_same_side_peak_240m, crowded_funding |
| 2026-05-04 12:08:00 | short | `canonical_trade_outcome` | -121.42 | 0.603 | 0.818 | 0.043 | -904.69 | 100.00 |  | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, broad_delta_conflict_24h, momentum_chase_60m, prior_same_side_peak_240m |
| 2026-05-11 00:28:00 | long | `canonical_trade_outcome` | 95.94 | 0.663 | 0.766 | 0.093 | 729.61 | 100.00 |  | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, oi_down_240m, momentum_chase_60m, prior_same_side_peak_240m, crowded_funding |
| 2026-05-15 04:52:00 | long | `canonical_trade_outcome` | 36.39 | 0.687 | 0.659 | 0.111 | -513.19 | 66.67 | SUPPORT | near_60m_extreme, vwap_extension_ge_0_5pct, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, poc_ahead, prior_same_side_peak_240m |
| 2026-05-29 17:10:00 | long | `canonical_trade_outcome` | 88.48 | 0.630 | 0.327 | 0.111 | 981.86 | 87.50 | SUPPORT | near_60m_extreme, near_240m_extreme, broad_delta_conflict_24h, momentum_chase_60m, prior_same_side_peak_240m, crowded_funding |
| 2026-06-12 01:41:00 | long | `canonical_trade_outcome` | 42.63 | 0.661 | 1.292 | 0.101 | -400.73 | 61.54 | SUPPORT | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, prior_same_side_peak_240m |
| 2026-06-21 23:10:00 | short | `canonical_trade_outcome` | -52.54 | 0.683 | 0.887 | 0.036 | -98.63 | 92.31 | SUPPORT | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, prior_same_side_peak_240m |
| 2026-06-26 14:44:00 | short | `canonical_trade_outcome` | -57.67 | 0.630 | 0.963 | 0.015 | -291.46 | 58.33 | SUPPORT | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, poc_ahead, prior_same_side_peak_240m |
| 2026-07-06 00:21:00 | long | `canonical_trade_outcome` | 177.89 | 0.654 | 1.039 | 0.146 | -348.37 | 100.00 |  | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, prior_same_side_peak_240m, crowded_funding |
| 2026-08-05 22:22:00 | long | `canonical_trade_outcome` | 89.92 | 0.658 | 0.976 | 0.105 | -1253.11 | 87.50 | REJECT | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, prior_same_side_peak_240m |
| 2026-08-07 14:56:00 | long | `canonical_trade_outcome` | 70.69 | 0.666 | 1.154 | 0.077 | 478.38 | 91.67 | REJECT | near_60m_extreme, near_240m_extreme, vwap_extension_ge_0_5pct, momentum_chase_60m, prior_same_side_peak_240m, crowded_funding |
| 2026-08-07 21:37:00 | long | `canonical_trade_outcome` | 17.37 | 0.667 | 0.373 | 0.029 | -129.17 | 20.00 | REJECT | near_60m_extreme, near_240m_extreme, weak_or_mid_peak_percentile, oi_down_60m, oi_down_240m, directional_move_with_oi_down_60m, momentum_chase_60m, poc_ahead, prior_same_side_peak_240m, crowded_funding |

## Interpretation guardrails

- `SL` alone is not a loss label; lifecycle flags control classification.
- Pattern prevalence is descriptive, not a causal proof or a ready-to-deploy trading rule.
- Fisher p-values are exploratory and unadjusted for multiple comparisons; the sample remains small.
- Protected controls are a small sample and one early control lacks an accepted-event join, so denominators are shown for every rate.
- The two user-confirmed losses have no canonical trade key/duration and remain visibly separated by provenance.
