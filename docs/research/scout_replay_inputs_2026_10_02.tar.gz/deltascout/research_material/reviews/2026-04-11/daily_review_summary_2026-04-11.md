# Daily Review Summary 2026-04-11

- processed_date: 2026-04-11
- accepted_row_count: 1
- reject_row_count: 24
- interesting_reject_row_count: 23
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-04-11.csv
- reject_reason_summary_group_count: 7
- reject_counts_by_reason:
  - 3of3_fail: 2
  - direction_mismatch: 10
  - ema50_vwap_regime: 1
  - vwap_side: 11
- files_created:
  - accepted_event_context_2026-04-11.csv
  - reject_event_context_2026-04-11.csv
  - interesting_rejects_2026-04-11.csv
  - reject_reason_summary_2026-04-11.csv
  - daily_review_summary_2026-04-11.md
