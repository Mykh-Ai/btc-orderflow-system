# Setup Candidate Discovery Summary

scope: `2026-03-17_to_2026-08-04`
move_threshold_usd: `1000`
candidate_rows: `551`

## Source Counts

- `accepted_peak_lifecycle_reference`: 15
- `interesting_reject`: 26
- `m2_6_chain_candidate`: 504
- `reject_1000_hit`: 6

## Track Counts

- `current_peak_emit_reference`: 15
- `m2_6_late_no_edge_warning`: 5
- `m2_6_process_chain`: 499
- `rejected_family_followthrough`: 32

## Direction Counts

- `long`: 275
- `short`: 276

## Accepted Lifecycle Coverage

- `inferred_sl_missing_peak_link`: 5
- `manual_confirmed_sl_result`: 1
- `no_trade_missed_entry`: 1
- `plain_loss_stop`: 4
- `protected_profit_trailing_stop`: 2
- `user_confirmed_sl_tp1_without_artifact_join`: 1
- `user_confirmed_sl_without_artifact_join`: 1

## Top Priority Candidates

- `2026-03-23 10:51:00` `long` `m2_6_chain_candidate` `m2_6_process_chain` score=3204.9 dir60=1881.5 fav60=
- `2026-06-25 13:35:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=3161.1 dir60=965.6 fav60=
- `2026-06-25 13:37:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=3136.8 dir60=1251.8 fav60=
- `2026-06-25 13:32:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=3120.4 dir60=1790.3 fav60=
- `2026-06-25 13:38:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=3071.6 dir60=1234.3 fav60=
- `2026-06-25 13:27:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=3032.8 dir60=1769.9 fav60=
- `2026-03-23 11:01:00` `long` `interesting_reject` `rejected_family_followthrough` score=2971.9 dir60=1441 fav60=2871.9
- `2026-06-25 13:39:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=2949.6 dir60=1134 fav60=
- `2026-06-25 13:40:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=2826.8 dir60=932.8 fav60=
- `2026-06-07 21:57:00` `long` `m2_6_chain_candidate` `m2_6_process_chain` score=2760.4 dir60=1191 fav60=
- `2026-06-25 12:54:00` `short` `m2_6_chain_candidate` `m2_6_process_chain` score=2731.7 dir60=2531.7 fav60=
- `2026-06-07 21:59:00` `long` `m2_6_chain_candidate` `m2_6_process_chain` score=2705.1 dir60=1152.1 fav60=

## Use

This file is a research surface, not a live signal spec.
Promote a row family only after clustered repeatability, lifecycle fit, and entry timing are reviewed.
