# Move-First Research Windows

scope: `2026-03-17_to_2026-08-04`
move_threshold_usd: `1000`
forward_minutes: `60`
move_window_count: `245`

## Direction Counts

- `long`: 129
- `short`: 116

## Detector Coverage

- move windows with nearby accepted PEAK: `3`
- move windows with no nearby accepted PEAK: `242`
- move windows with nearby M2.6 candidate: `245`
- move windows with nearby reject row: `134`
- move windows with no nearby accepted/M2.6/reject annotation: `0`

## Top Move-First Windows

- `2026-04-07_long_mf065` `2026-04-07 21:28:00` -> `2026-04-07 23:20:00` `long` fav60=2363.3 best=2026-04-07 23:08:00 adverse=1.9 accepted=0 m2_6=245 rejects=1
- `2026-04-17_long_mf090` `2026-04-17 12:09:00` -> `2026-04-17 13:08:00` `long` fav60=1435.3 best=2026-04-17 12:44:00 adverse=1.6 accepted=0 m2_6=155 rejects=1
- `2026-04-14_long_mf080` `2026-04-14 12:48:00` -> `2026-04-14 13:42:00` `long` fav60=1394.6 best=2026-04-14 12:58:00 adverse=1.8 accepted=0 m2_6=150 rejects=2
- `2026-04-17_long_mf091` `2026-04-17 13:27:00` -> `2026-04-17 13:51:00` `long` fav60=1622.4 best=2026-04-17 13:32:00 adverse=50.7 accepted=0 m2_6=150 rejects=0
- `2026-03-19_short_mf012` `2026-03-19 06:16:00` -> `2026-03-19 07:06:00` `short` fav60=1433.3 best=2026-03-19 06:19:00 adverse=0.1 accepted=0 m2_6=145 rejects=1
- `2026-03-27_short_mf041` `2026-03-27 09:43:00` -> `2026-03-27 10:38:00` `short` fav60=1553.1 best=2026-03-27 10:34:00 adverse=6.3 accepted=0 m2_6=130 rejects=1
- `2026-04-13_long_mf079` `2026-04-13 21:17:00` -> `2026-04-13 22:16:00` `long` fav60=1610 best=2026-04-13 21:32:00 adverse=1.6 accepted=0 m2_6=125 rejects=1
- `2026-04-09_long_mf071` `2026-04-09 14:22:00` -> `2026-04-09 15:20:00` `long` fav60=1648 best=2026-04-09 15:10:00 adverse=0.5 accepted=0 m2_6=125 rejects=1
- `2026-04-17_long_mf089` `2026-04-17 08:29:00` -> `2026-04-17 08:47:00` `long` fav60=1280.8 best=2026-04-17 08:47:00 adverse=3.8 accepted=0 m2_6=135 rejects=2
- `2026-03-31_long_mf049` `2026-03-31 15:43:00` -> `2026-03-31 16:40:00` `long` fav60=1690.9 best=2026-03-31 15:59:00 adverse=9.4 accepted=0 m2_6=120 rejects=1
- `2026-03-17_long_mf003` `2026-03-17 14:01:00` -> `2026-03-17 14:30:00` `long` fav60=1424 best=2026-03-17 14:26:00 adverse=22.7 accepted=0 m2_6=130 rejects=1
- `2026-04-17_long_mf092` `2026-04-17 14:14:00` -> `2026-04-17 14:14:00` `long` fav60=1001.3 best=2026-04-17 14:14:00 adverse=47.5 accepted=0 m2_6=145 rejects=0
- `2026-04-13_long_mf078` `2026-04-13 18:49:00` -> `2026-04-13 19:18:00` `long` fav60=1191.7 best=2026-04-13 19:15:00 adverse=0.2 accepted=0 m2_6=130 rejects=0
- `2026-03-23_long_mf021` `2026-03-23 10:06:00` -> `2026-03-23 11:08:00` `long` fav60=3194.5 best=2026-03-23 10:56:00 adverse=4.3 accepted=0 m2_6=80 rejects=1
- `2026-04-08_short_mf070` `2026-04-08 14:02:00` -> `2026-04-08 14:03:00` `short` fav60=1027.1 best=2026-04-08 14:02:00 adverse=25.1 accepted=0 m2_6=135 rejects=0
- `2026-04-09_long_mf072` `2026-04-09 15:27:00` -> `2026-04-09 15:32:00` `long` fav60=1088.5 best=2026-04-09 15:32:00 adverse=34.1 accepted=0 m2_6=130 rejects=1
- `2026-04-08_short_mf068` `2026-04-08 13:08:00` -> `2026-04-08 13:38:00` `short` fav60=1450.4 best=2026-04-08 13:34:00 adverse=38.8 accepted=0 m2_6=115 rejects=2
- `2026-03-31_long_mf046` `2026-03-31 00:24:00` -> `2026-03-31 01:20:00` `long` fav60=1618.9 best=2026-03-31 01:12:00 adverse=4.7 accepted=0 m2_6=105 rejects=0
- `2026-03-18_short_mf007` `2026-03-18 10:31:00` -> `2026-03-18 11:29:00` `short` fav60=1336.5 best=2026-03-18 11:22:00 adverse=3.5 accepted=0 m2_6=110 rejects=0
- `2026-03-23_short_mf026` `2026-03-23 11:09:00` -> `2026-03-23 11:44:00` `short` fav60=1657.8 best=2026-03-23 11:41:00 adverse=7 accepted=0 m2_6=105 rejects=0

## Use

This artifact starts from market movement, not PEAK/M2.6/reject rows.
Use detector fields only to ask whether existing logic saw the move, missed it, or filtered it.
