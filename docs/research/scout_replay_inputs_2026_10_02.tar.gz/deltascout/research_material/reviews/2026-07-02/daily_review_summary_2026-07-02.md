# Daily Review Summary 2026-07-02

- processed_date: 2026-07-02
- accepted_row_count: 0
- reject_row_count: 22
- interesting_reject_row_count: 20
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-07-02.csv
- reject_reason_summary_group_count: 4
- reject_counts_by_reason:
  - direction_mismatch: 11
  - vwap_distance: 2
  - vwap_side: 9
- files_created:
  - accepted_event_context_2026-07-02.csv
  - reject_event_context_2026-07-02.csv
  - interesting_rejects_2026-07-02.csv
  - reject_reason_summary_2026-07-02.csv
  - daily_review_summary_2026-07-02.md
