# Daily Review Summary 2026-06-02

- processed_date: 2026-06-02
- accepted_row_count: 0
- reject_row_count: 23
- interesting_reject_row_count: 17
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-06-02.csv
- reject_reason_summary_group_count: 5
- reject_counts_by_reason:
  - chop_coh: 1
  - direction_mismatch: 11
  - vwap_distance: 5
  - vwap_side: 6
- files_created:
  - accepted_event_context_2026-06-02.csv
  - reject_event_context_2026-06-02.csv
  - interesting_rejects_2026-06-02.csv
  - reject_reason_summary_2026-06-02.csv
  - daily_review_summary_2026-06-02.md
