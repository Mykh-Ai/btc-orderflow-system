# Daily Review Summary 2026-04-09

- processed_date: 2026-04-09
- accepted_row_count: 1
- reject_row_count: 18
- interesting_reject_row_count: 17
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-04-09.csv
- reject_reason_summary_group_count: 7
- reject_counts_by_reason:
  - 3of3_fail: 3
  - chop_coh: 1
  - direction_mismatch: 7
  - vwap_side: 7
- files_created:
  - accepted_event_context_2026-04-09.csv
  - reject_event_context_2026-04-09.csv
  - interesting_rejects_2026-04-09.csv
  - reject_reason_summary_2026-04-09.csv
  - daily_review_summary_2026-04-09.md
