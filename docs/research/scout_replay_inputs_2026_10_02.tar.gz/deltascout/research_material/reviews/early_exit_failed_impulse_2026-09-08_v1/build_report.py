"""Render the fixed experiment and independently reconcile its exported legs."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
a = json.loads((ROOT/'analysis.json').read_text(encoding='utf-8'))
manifest = json.loads((ROOT/'experiment_manifest.json').read_text(encoding='utf-8'))
for item in manifest['sources'] + manifest['outputs']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']

checked = 0
for scenario, trades in a['trades'].items():
    for t in trades:
        if t['entry_status'] != 'FILLED':
            assert not t['legs'] and t['net_pnl_usdc'] == 0
            continue
        checked += 1
        sign = 1 if t['side'] == 'LONG' else -1
        qty = sum(leg['qty'] for leg in t['legs'])
        assert math.isclose(qty, t['qty_total'], abs_tol=1e-10)
        gross = sum(sign*leg['qty']*(leg['exit_price']-t['entry_fill_price']) for leg in t['legs'])
        commission = (t['qty_total']*t['entry_fill_price']+sum(leg['qty']*leg['exit_price'] for leg in t['legs']))*.000744
        slip = sum(leg['qty']*leg['exit_price']*(.0002 if leg['leg_type'] in {'INITIAL_STOP','BREAKEVEN_STOP','TRAILING_STOP'} else .0001) for leg in t['legs'])
        assert math.isclose(t['net_pnl_usdc'], gross-commission-slip, abs_tol=1e-8)

names = dict(all_independent='Без фільтра, незалежні', all_portfolio='Без фільтра, портфель',
             ab_independent='A/B, незалежні', ab_portfolio='A/B, портфель')
lines = ['# Пункт 3: ранній вихід після невдалого імпульсу', '',
'**Висновок: перевірене правило відхиляємо для впровадження.** На цій історичній вибірці воно знижує PnL і збільшує просадку основного A/B-портфеля. Це висновок щодо одного правила, а не щодо всіх можливих ранніх виходів.', '',
'## Що саме перевірено', '',
'Одна зафіксована до розрахунку гіпотеза: від 60-ї хвилини після модельного входу, до TP1, MFE ≥0,5R, поточна ціна відносно входу ≤0R та протилежна дельта за останні 15 завершених хвилин. Перевірка щохвилини до TP1 або закриття, без максимального віку; слово «ранній» тут означає до TP1, а не лише в першу годину. Це протилежна недавня дельта, без додаткової вимоги попередньої позитивної дельти.', '',
'Вихід за Open наступної хвилини. Нульова дельта не є протилежною. R = абсолютна відстань між фактичним модельним входом і початковим SL. Екстремуми свічки входу виключено; її Close доступний. SL/TP1 на хвилині рішення мають пріоритет. Якщо Open наступної хвилини вже за standing SL/TP1, зберігається базова обробка цих ордерів.', '',
'Однакові входи, фільтри, розмір 3000 USDC на позицію, SL/TP/trailing, комісія 0,000744 з обороту, slippage 0/1/2 bps для входу/звичайного виходу/стопа. Borrow interest не включено. Live та сервер не змінювалися.', '',
'## Результат', '',
'| Вибірка | Угод: база → варіант | Net база, USDC | Net варіант, USDC | Зміна, USDC | Просадка база → варіант, USDC |',
'|---|---:|---:|---:|---:|---:|']
for key,s in a['summaries'].items():
    b,v=s['baseline'],s['variant']
    lines.append(f"| {names[key]} | {b['filled']} → {v['filled']} | {b['net_usdc']:+.2f} | {v['net_usdc']:+.2f} | {s['net_change_usdc']:+.2f} | {b['max_closed_trade_drawdown_usdc']:.2f} → {v['max_closed_trade_drawdown_usdc']:.2f} |")
lines += ['', 'Просадка тут розрахована за PnL повністю закритих позицій, як у базі; це не внутрішньоугодова mark-to-market просадка. Незалежні угоди можуть перекриватися, тому це діагностика можливостей, а не один виконуваний портфель.', '',
'## Звідки зміна A/B-портфеля', '',
'- 4 колишні plain SL: покращення **+136,21 USDC**.',
'- 3 колишні TP1→SL: погіршення **−35,43 USDC**.',
'- 2 колишні TP2/trailing: погіршення **−145,79 USDC**.',
'- Разом на спільних угодах: **−45,01 USDC**.',
'- Раніше звільнене місце дозволило додатковий SHORT 11.04, який закрився по SL: **−44,79 USDC**.',
'- Загальна зміна: **−89,80 USDC**, без зниклих угод.', '',
'9 спрацювань у A/B-портфелі; 8 LONG і 1 SHORT. Profit factor: 1,93 → 1,71. У незалежному A/B розрахунку PF трохи зростає (1,58 → 1,61), але PnL падає: сам PF не є достатньою метою оптимізації.', '',
'## Кожне спрацювання та додаткова угода', '',
'Час сигналу — UTC. Вік рішення від завершеної свічки входу; це не точний вік від біржового fill. Дельта — частка buy/sell volume зі знаком напрямку позиції, показана у %.', '',
'| Сигнал UTC | Сторона | Базовий результат | Вік рішення, хв | MFE, R | Недавня дельта | Net база → варіант, USDC | Зміна |',
'|---|---|---|---:|---:|---:|---:|---:|']
audits={r['candidate_id']:r for r in a['audits']['ab']}
for r in a['comparisons']['ab_portfolio']:
    if not r['early_exit'] and r['membership_change']!='ADDED':
        continue
    d=audits[r['candidate_id']]['decision']
    age=f"{d['age_min']:.0f}" if d else '—'
    mfe=f"{d['mfe_r']:.3f}" if d else '—'
    delta=f"{d['directional_delta_pct']*100:.2f}%" if d else '—'
    label=r['baseline_lifecycle'] if r['membership_change']=='COMMON' else 'Додана після звільнення місця'
    lines.append(f"| {r['signal_ts_utc'][:16].replace('T',' ')} | {r['side']} | {label} | {age} | {mfe} | {delta} | {r['baseline_net_usdc']:+.2f} → {r['variant_net_usdc']:+.2f} | {r['delta_net_usdc']:+.2f} |")
lines += ['', 'Спрацювання на 2465-й хвилині — наслідок відсутності верхньої межі віку в зафіксованому правилі. MFE понад 1R до TP1 можливий: R для ознаки виміряно від фактичного fill до SL, а рівень TP1 у базовій політиці спланований до fill. Це різні величини; TP1 визначається фактичним торканням його запланованої ціни.', '',
'## Перевірки та обмеження', '',
f'- Звірено 636 frozen inputs та fingerprint базового replay. Відтворено базові незалежні й портфельні результати для 48 кандидатів без фільтра і 30 з A/B; перевірено всі поля, крім run fingerprint та невикористаного прапорця альтернативної same-bar sensitivity.',
f'- Незалежно перераховано кількість і net PnL усіх {checked} виконаних записів у чотирьох variant cohorts із їхніх експортованих legs.',
'- 104 тести пройшли, включно з 16 тестами нового правила: long/short симетрія, доступність даних, пріоритет SL/TP1, next-open, відсутність витоку майбутніх labels/цін, переобчислення портфеля.',
'- На перевірених потенційних спрацюваннях немає пропущених flow-вікон, конфліктів standing SL/TP1 на Open або пропущених наступних execution-хвилин. Це не твердження про повноту всього архіву.',
'- У A/B одна з 9 exit-ознак використовує 15 recovered-хвилин: 26.04. Використано clock-corrected legacy price/volume/delta та sidecars. Funding, liquidations і OI не є ознаками раннього виходу.',
'- Історію вже розглядали раніше, тому результат не є out-of-sample. Пороги після прогону не оптимізували. Один приклад не доводить універсальну непридатність ранніх виходів.',
'- Час exit/звільнення слота зберігає completed-bar convention бази: до хвилини пізніше за timestamp ціни Open. Реальна затримка збору даних/відправлення ордера окремо не моделюється.', '',
'Практичне рішення: зберегти чинне управління позицією. Наступна гіпотеза потребує незалежної причини втрати структури/сетапу та окремого зафіксованого тесту. Саме повернення після імпульсу разом із протилежною 15-хвилинною дельтою в цій вибірці недостатньо вибіркове.', '',
'Артефакти: [analysis.json](analysis.json), [protocol.json](protocol.json), [replay_events.json](replay_events.json), [experiment_manifest.json](experiment_manifest.json).', '']
(ROOT/'report_uk.md').write_text('\n'.join(lines),encoding='utf-8')
print(f'Reconciled {checked} filled scenario records; source/output hashes verified; report_uk.md written')
