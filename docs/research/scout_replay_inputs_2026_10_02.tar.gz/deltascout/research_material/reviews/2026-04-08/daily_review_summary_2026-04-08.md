# Daily Review Summary 2026-04-08

- processed_date: 2026-04-08
- accepted_row_count: 0
- reject_row_count: 19
- interesting_reject_row_count: 14
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-04-08.csv
- reject_reason_summary_group_count: 5
- reject_counts_by_reason:
  - direction_mismatch: 10
  - vwap_distance: 5
  - vwap_side: 4
- files_created:
  - accepted_event_context_2026-04-08.csv
  - reject_event_context_2026-04-08.csv
  - interesting_rejects_2026-04-08.csv
  - reject_reason_summary_2026-04-08.csv
  - daily_review_summary_2026-04-08.md
