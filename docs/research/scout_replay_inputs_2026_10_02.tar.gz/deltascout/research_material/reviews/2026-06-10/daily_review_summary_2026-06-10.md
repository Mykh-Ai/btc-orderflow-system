# Daily Review Summary 2026-06-10

- processed_date: 2026-06-10
- accepted_row_count: 1
- reject_row_count: 19
- interesting_reject_row_count: 16
- accepted_with_close_outcomes: 1
- reject_reason_summary_created: reject_reason_summary_2026-06-10.csv
- reject_reason_summary_group_count: 6
- reject_counts_by_reason:
  - 3of3_fail: 2
  - chop_coh: 2
  - direction_mismatch: 8
  - vwap_side: 7
- files_created:
  - accepted_event_context_2026-06-10.csv
  - reject_event_context_2026-06-10.csv
  - interesting_rejects_2026-06-10.csv
  - reject_reason_summary_2026-06-10.csv
  - daily_review_summary_2026-06-10.md
