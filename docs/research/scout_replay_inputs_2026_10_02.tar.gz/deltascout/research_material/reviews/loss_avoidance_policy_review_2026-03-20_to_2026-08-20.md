# Loss-Avoidance Policy Review

## Utility contract

- Target: reduce full `SL without TP1` losses.
- Neutral: `TP1 -> SL`, including a tiny fee-adjusted loss.
- Protect: trades that reached both `TP1 + TP2` and trailing protection.
- The costly false positive is a rule match on the protected cohort, not on the scratch cohort.

## Candidate coverage

| Rule | Plain losses covered | TP1->SL scratches covered | Protected TP1+TP2 covered |
|---|---:|---:|---:|
| `weak_peak_le_50` | 4/18 (22%) | 1/11 (9%) | 0/7 (0%) |
| `oi_down_60_and_directional_delta_pct_240_lt_0_06` | 7/18 (39%) | 2/11 (18%) | 0/7 (0%) |
| `conservative_union` | 9/18 (50%) | 3/11 (27%) | 0/7 (0%) |
| `exploratory_union_peak_le_60` | 10/18 (56%) | 5/11 (45%) | 0/7 (0%) |

## Current best shadow hypothesis

The conservative union flags a signal when either:

1. its same-side delta candidate is at or below the 50th percentile of the preceding 24h; or
2. trusted OI is falling over 60m while the direction-adjusted 240m buy/sell delta share is below 6%.

This describes two related failure modes: a weak event by itself, or a local impulse occurring while participation is shrinking and the broad directional flow is weak. Falling OI alone is deliberately not used because it also occurred in protected winners, including the latest strong trade.

## TP1->SL fee audit

- Scratch trades in the feature cohort: **11**.
- Net-after-commission result known or reconstructed: **6**.
- Positive gross PnL flipped slightly negative by estimated commission: **1**.
- Estimated commission rate from actual overlapping fills: **0.0744% of turnover** (7 observations).
- Borrow interest is not present in the snapshots and is excluded; this does not change the neutral utility bucket.

| Signal local | Trade | Gross USDC | Commission USDC | Net USDC | Evidence |
|---|---|---:|---:|---:|---|
| 2026-04-12 03:36:00 | `EX_EN_1775957763` |  |  |  | `lifecycle_only_no_execution_pnl` |
| 2026-04-26 07:13:00 | `EX_EN_1777180402` |  |  |  | `lifecycle_only_no_execution_pnl` |
| 2026-04-28 09:17:00 | `EX_EN_1777360623` |  |  |  | `lifecycle_only_no_execution_pnl` |
| 2026-05-08 02:57:00 | `EX_EN_1778201828` |  |  |  | `lifecycle_only_no_execution_pnl` |
| 2026-05-08 19:31:00 | `EX_EN_1778261477` |  |  |  | `lifecycle_only_no_execution_pnl` |
| 2026-06-10 04:18:00 | `EX_EN_1781057890` | 10.57 | 4.46 | 6.11 | `snapshot_gross_fee_rate_estimated` |
| 2026-06-16 15:09:00 | `EX_EN_1781615351` | 7.56 | 4.38 | 3.18 | `ledger_actual` |
| 2026-06-25 15:46:00 | `EX_EN_1782395166` | 22.88 | 4.35 | 18.53 | `ledger_actual` |
| 2026-06-29 15:47:00 | `EX_EN_1782740830` | 25.63 | 4.40 | 21.23 | `ledger_fee_estimated` |
| 2026-07-10 10:17:00 | `EX_EN_1783671425` | 6.15 | 4.49 | 1.66 | `ledger_actual` |
| 2026-07-26 02:26:00 | `EX_EN_1785025567` | 3.08 | 4.46 | -1.39 | `snapshot_gross_fee_rate_estimated` |

## Trades matched by the conservative hypothesis

### Plain losses

- 2026-03-20 00:40:00 short `EX_EN_1773963610`
- 2026-04-04 23:56:00 long `EX_EN_1775339769`
- 2026-04-23 10:45:00 short `EX_EN_1776933907`
- 2026-05-15 04:52:00 long `EX_EN_1778813539`
- 2026-06-12 01:41:00 long `EX_EN_1781221266`
- 2026-06-21 23:10:00 short `EX_EN_1782076213`
- 2026-06-26 14:44:00 short `EX_EN_1782477849`
- 2026-08-07 21:37:00 long `EX_EN_1786131443`
- 2026-04-05 14:34:00 short `manual-confirmed`

### TP1->SL scratches

- 2026-05-08 19:31:00 long `EX_EN_1778261477`
- 2026-06-10 04:18:00 short `EX_EN_1781057890`
- 2026-06-29 15:47:00 short `EX_EN_1782740830`

### Protected TP1+TP2

- None in the signal-joined sample.

## Decision

Keep this as an offline/shadow score, not a live veto. Journal both component flags separately. Promotion requires prospective observations and continued zero/near-zero coverage of TP1+TP2 winners.

## Guardrails

- All features are pre-entry and use the corrected Bratislava-local to UTC feed join.
- The thresholds were inspected on this same small sample and therefore are exploratory.
- Zero protected matches means 0 of 7 signal-joined controls, not a guarantee over future trades.
- One of 8 canonical protected trades lacks a comparable accepted-signal join.
- No candidate is authorized as a live hard veto by this report.
