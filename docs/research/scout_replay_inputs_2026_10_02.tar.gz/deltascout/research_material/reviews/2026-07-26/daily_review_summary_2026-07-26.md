# Daily Review Summary 2026-07-26

- processed_date: 2026-07-26
- accepted_row_count: 1
- reject_row_count: 16
- interesting_reject_row_count: 12
- accepted_with_close_outcomes: 1
- reject_reason_summary_created: reject_reason_summary_2026-07-26.csv
- reject_reason_summary_group_count: 4
- reject_counts_by_reason:
  - 3of3_fail: 1
  - direction_mismatch: 11
  - vwap_side: 4
- files_created:
  - accepted_event_context_2026-07-26.csv
  - reject_event_context_2026-07-26.csv
  - interesting_rejects_2026-07-26.csv
  - reject_reason_summary_2026-07-26.csv
  - daily_review_summary_2026-07-26.md
