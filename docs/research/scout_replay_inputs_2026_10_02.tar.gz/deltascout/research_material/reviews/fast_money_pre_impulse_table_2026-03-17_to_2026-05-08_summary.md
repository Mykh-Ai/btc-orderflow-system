# Fast Money Pre-Impulse Table Summary

scope: `2026-03-17_to_2026-05-08`
rows: `218`
fast_money_trigger_rows: `56`

## Proxy Kinds

- `best_proxy`: 109
- `earliest_proxy`: 109

## Candidate Families

- `FAST_MONEY_COUNTERTREND_IMPULSE`: 108
- `FAST_MONEY_LONG_FORERUNNER`: 49
- `FAST_MONEY_LONG_PRE_IMPULSE`: 18
- `FAST_MONEY_SHORT_LATE_RISK`: 8
- `FAST_MONEY_SHORT_PRE_IMPULSE`: 35

## Phase Labels

- `acceleration_trigger`: 26
- `countertrend_impulse`: 108
- `early_watch`: 27
- `late_after_impulse`: 8
- `reversal_forerunner`: 49

## Use

This table is an event-study surface for pre-impulse / fast-money research, not a live signal spec.
Use it to compare early watch vs lower-adverse trigger timing, stop survival, and PEAK delay.
