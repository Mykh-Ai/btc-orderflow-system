# Fast Money Pre-Impulse Review

scope: `2026-03-17_to_2026-05-02`

Source artifacts:

- `top_cluster_manual_review_2026-03-17_to_2026-05-02.csv`
- `setup_cluster_review_2026-03-17_to_2026-05-02.csv`
- `setup_candidates_2026-03-17_to_2026-05-02.csv`
- `move_first_windows_2026-03-17_to_2026-05-02.csv`
- user chart review and regime notes

## Executive Verdict

The five reviewed proxy entries are best treated as `fast_money_pre_impulse` locations.

They are not generic continuation rows. They are entry zones immediately before fast directional expansion. The research target should be:

```text
detect the pre-impulse state before fast directional movement, then decide whether the impulse is trend-aligned, reversal-forerunner, or counter-trend correction.
```

## Confirmed Proxy Entries

| cluster | side | proxy ts | proxy price | time to $1000 | adverse before $1000 | user role |
|---|---:|---|---:|---:|---:|---|
| `2026-03-23_long_c005` | long | `2026-03-23 10:51` | `68463.1` | `15m` | `102.5` | early internal long impulse / precursor inside downtrend |
| `2026-03-21_short_c004` | short | `2026-03-21 23:02` | `70231` | `51m` | `15` | validated short pre-impulse |
| `2026-04-07_long_c025` | long | `2026-04-07 22:33` | `70660` | `28m` | `234.5` | first stronger upward reversal forerunner |
| `2026-04-16_short_c037` | short | `2026-04-16 13:29` | `74894.7` | `24m` | `86.4` | counter-trend downside impulse inside broader long correction |
| `2026-04-12_short_c032` | short | `2026-04-12 00:50` | `72976.6` | `50m` | `117.8` | validated short pre-impulse |

## Shared Fast-Money Structure

Durable facts:

- All five confirmed clusters are M2.6 process-chain clusters.
- All five hit `$1000+` favorable movement after the representative proxy entry.
- All five had no nearby accepted PEAK before the move.
- Two long clusters have rejected-family support:
  - `2026-03-23_long_c005`: `3of3_fail`
  - `2026-04-07_long_c025`: `direction_mismatch`
- Current PEAK either did not see the move or arrived late:
  - `2026-04-16_short_c037`: later nearby accepted PEAK was `15:53 short NO_TRADE/no_trade_missed_entry`.
  - `2026-04-12_short_c032`: later nearby accepted PEAK was `03:36 short SL/inferred_sl_missing_peak_link`.

Durable interpretation:

- M2.6 is acting as the broad pre-impulse detector.
- Rejected PEAK rows can act as confirmation or conflict markers, but they are not required for the fast-money class.
- Accepted PEAK is not the primary source of these opportunities.
- The representative proxy often sits after the first detector mark but before the stronger acceleration.

## Earliest Proxy vs Best Proxy

Move-first windows show two different useful timestamps:

- `earliest_proxy_ts`: first detectable movement-zone annotation.
- `best_proxy_ts`: later lower-adverse acceleration point.

Examples:

| move window | earliest proxy | earliest adverse | best proxy | best adverse | lesson |
|---|---|---:|---|---:|---|
| `2026-03-23_long_mf021` | `10:06` | `203.9` | `10:56` | `4.3` | early detector was valid, but acceleration timing was cleaner later |
| `2026-03-21_short_mf017` | `22:53` | `29` | `23:43` | `3.2` | late acceleration proxy had much cleaner adverse |
| `2026-04-07_long_mf065` | `21:28` | `35.4` | `23:08` | `1.9` | broad move began earlier, best timing came into acceleration |
| `2026-04-12_short_mf075` | `00:37` | `39.5` | `01:22` | `0.6` | M2.6 saw zone early, best short timing came later |
| `2026-04-16_short_mf088` | `12:55` | `415.1` | `13:45` | `6` | counter-trend short required waiting past noisy sweep risk |

Research implication:

The future `AI_EMIT` class should not emit only on first detection. It should separate:

- `PRE_IMPULSE_WATCH`: early movement-zone detection.
- `FAST_MONEY_TRIGGER`: lower-adverse acceleration entry.
- `LATE_NO_EDGE`: after the impulse is already mature.

## Regime And Direction Classification

The five entries do not belong to one simple direction class.

### Long Forerunners

`2026-03-23_long_c005`

- User classification: early internal long impulse / precursor inside the larger downtrend.
- Quant: `$3004.9` favorable after representative proxy, `$102.5` adverse before `$1000`.
- Context: not confirmed macro reversal yet.

`2026-04-07_long_c025`

- User classification: first stronger upward-reversal forerunner.
- Larger chain: first leg from roughly `68700` to `72700`, second leg toward roughly `76200` by `2026-04-14`.
- Quant: `$2083.4` favorable after representative proxy, `$234.5` adverse before `$1000`.
- Has reject support via `direction_mismatch`.

### Short Pre-Impulse / Correction Family

`2026-03-21_short_c004`

- Clean M2.6 short pre-impulse cluster.
- Strong negative flow alignment inside the cluster.
- Quant: `$2042` favorable after representative proxy, only `$15` adverse before `$1000`.

`2026-04-12_short_c032`

- Short pre-impulse cluster with later accepted PEAK likely arriving too late.
- Quant: `$1717.6` favorable after representative proxy, `$117.8` adverse before `$1000`.

`2026-04-16_short_c037`

- User classification: counter-trend downside impulse, not simple short continuation.
- Broader context: correction inside larger upward reversal/base process.
- Around `15:50`, US session/premarket flow swept stops near `73400`, then price reversed higher toward roughly `78300` on `2026-04-17`.
- Lesson: stop model and session context matter more than direction label.

## Candidate Fast-Money Features

Features that repeat enough to test:

1. Dense M2.6 clustering before movement.
   - All five reviewed entries are M2.6 process-chain clusters.
   - Higher row count appears meaningful, but small clusters can still work.

2. Movement-zone appears before PEAK.
   - Accepted PEAK is absent or late.
   - This supports a future AI layer that listens to M2.6 before PEAK confirmation.

3. VWAP-side is useful but not absolute.
   - Long clusters are mostly `above`, but representative proxy can be `below`.
   - Short clusters are mostly `below`, but some above-VWAP rows can appear during noisy transition.
   - VWAP should be read as structure/phase context, not a hard standalone gate.

4. Flow alignment differs by class.
   - `2026-04-07_long_c025` has strong positive `cum_delta_24h/180m/60m`.
   - `2026-03-21_short_c004` has strong negative alignment.
   - `2026-04-16_short_c037` has positive higher-horizon flow during a local downside impulse, matching its counter-trend correction role.

5. Best trigger often comes after first detection.
   - Earliest proxies can be valid but carry larger adverse risk.
   - Best proxies often occur closer to acceleration and with materially smaller adverse before `$1000`.

6. Session context can decide stop survival.
   - `2026-04-16_short_c037` shows that a directionally correct local short can fail with too tight a stop during US stop-run behavior.

## Proposed AI_EMIT Research Grammar

Do not draft one universal signal yet. Split the grammar:

### `FAST_MONEY_LONG_FORERUNNER`

Candidate examples:

- `2026-03-23_long_c005`
- `2026-04-07_long_c025`

Current concept:

- early or first stronger upward impulse inside bottoming/base-building regime;
- M2.6 cluster before accepted PEAK;
- may include reject support;
- should test whether proxy is before acceleration, not after obvious trend maturity.

### `FAST_MONEY_SHORT_PRE_IMPULSE`

Candidate examples:

- `2026-03-21_short_c004`
- `2026-04-12_short_c032`

Current concept:

- short-side pre-impulse cluster with M2.6 density;
- accepted PEAK absent or later;
- needs stop model that survives normal pre-release noise.

### `FAST_MONEY_COUNTERTREND_IMPULSE`

Candidate example:

- `2026-04-16_short_c037`

Current concept:

- local impulse against broader direction;
- must be treated as fast tactical movement, not a swing continuation;
- should require stricter time-to-move and session-aware stop/invalidation.

## What To Test Next

1. Build a `fast_money_pre_impulse` table from all move-first windows.
   - Include earliest proxy and best proxy.
   - Include M2.6 density in the previous `15/30/60` minutes.
   - Include reject support and reject reason when present.
   - Include nearby accepted PEAK timing and lifecycle when present.

2. Add phase labels:
   - `early_watch`
   - `acceleration_trigger`
   - `late_after_impulse`
   - `countertrend_impulse`
   - `reversal_forerunner`

3. Compare adverse profiles:
   - earliest proxy adverse;
   - representative proxy adverse;
   - best proxy adverse;
   - whether adverse is normal noise, session stop-run, or invalidation.

4. Promote only if repeatable:
   - same pre-impulse structure repeats across other move-first windows;
   - entry can be defined before the move, not from hindsight;
   - stop model is explicit;
   - target can plausibly capture `$1000+` movement.

## Current Priority Call

Research should dig into `fast_money_pre_impulse` next.

The most valuable question is not:

```text
was this row long or short?
```

The better question is:

```text
what recurring state appears immediately before fast directional impulse, and when does it become tradable with acceptable adverse?
```
