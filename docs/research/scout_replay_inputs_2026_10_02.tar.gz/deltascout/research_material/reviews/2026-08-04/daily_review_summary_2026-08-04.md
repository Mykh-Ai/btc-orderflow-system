# Daily Review Summary 2026-08-04

- processed_date: 2026-08-04
- accepted_row_count: 0
- reject_row_count: 11
- interesting_reject_row_count: 9
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-08-04.csv
- reject_reason_summary_group_count: 5
- reject_counts_by_reason:
  - direction_mismatch: 7
  - ema50_vwap_regime: 1
  - imb_band: 1
  - vwap_side: 2
- files_created:
  - accepted_event_context_2026-08-04.csv
  - reject_event_context_2026-08-04.csv
  - interesting_rejects_2026-08-04.csv
  - reject_reason_summary_2026-08-04.csv
  - daily_review_summary_2026-08-04.md
