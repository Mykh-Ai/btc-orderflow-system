# DeltaScout final research review `2026-04-06_to_2026-05-02`

## Part 1 - Compact batch summary

### 1) Daily snapshot
- Fact: `2026-04-06` accepted `0`, rejects `19`, interesting rejects `15`, close outcomes `0`; top reject reasons: direction_mismatch=8, vwap_side=7; dominant buckets: unclear_but_constructive=12, possible_trap_or_false_break=2.
- Fact: `2026-04-07` accepted `0`, rejects `21`, interesting rejects `18`, close outcomes `0`; top reject reasons: direction_mismatch=11, vwap_side=5; dominant buckets: unclear_but_constructive=17, possible_trap_or_false_break=1.
- Fact: `2026-04-08` accepted `0`, rejects `19`, interesting rejects `14`, close outcomes `0`; top reject reasons: direction_mismatch=10, vwap_distance=5; dominant buckets: unclear_but_constructive=13, possible_reversal_confirmation=1.
- Fact: `2026-04-09` accepted `1`, rejects `18`, interesting rejects `17`, close outcomes `0`; top reject reasons: direction_mismatch=7, vwap_side=7; dominant buckets: unclear_but_constructive=11, possible_reversal_confirmation=3.
- Fact: `2026-04-10` accepted `0`, rejects `17`, interesting rejects `16`, close outcomes `0`; top reject reasons: direction_mismatch=8, vwap_side=5; dominant buckets: unclear_but_constructive=11, possible_reversal_confirmation=2.
- Fact: `2026-04-11` accepted `1`, rejects `24`, interesting rejects `23`, close outcomes `0`; top reject reasons: vwap_side=11, direction_mismatch=10; dominant buckets: unclear_but_constructive=16, possible_reversal_confirmation=4.
- Fact: `2026-04-12` accepted `1`, rejects `15`, interesting rejects `13`, close outcomes `0`; top reject reasons: direction_mismatch=8, vwap_side=5; dominant buckets: unclear_but_constructive=10, possible_reversal_confirmation=1.
- Fact: `2026-04-13` accepted `0`, rejects `19`, interesting rejects `16`, close outcomes `1`; top reject reasons: direction_mismatch=9, vwap_side=5; dominant buckets: unclear_but_constructive=11, possible_reversal_onset=3.
- Fact: `2026-04-14` accepted `0`, rejects `25`, interesting rejects `16`, close outcomes `0`; top reject reasons: direction_mismatch=10, vwap_distance=9; dominant buckets: unclear_but_constructive=15, possible_continuation_pressure=1.
- Fact: `2026-04-15` accepted `0`, rejects `22`, interesting rejects `19`, close outcomes `0`; top reject reasons: direction_mismatch=13, 3of3_fail=5; dominant buckets: unclear_but_constructive=14, possible_reversal_confirmation=2.
- Fact: `2026-04-16` accepted `1`, rejects `22`, interesting rejects `21`, close outcomes `1`; top reject reasons: direction_mismatch=12, vwap_side=9; dominant buckets: unclear_but_constructive=15, possible_reversal_onset=4.
- Fact: `2026-04-17` accepted `1`, rejects `17`, interesting rejects `15`, close outcomes `1`; top reject reasons: direction_mismatch=11, 3of3_fail=2; dominant buckets: unclear_but_constructive=12, possible_reversal_onset=2.
- Fact: `2026-04-18` accepted `0`, rejects `18`, interesting rejects `18`, close outcomes `0`; top reject reasons: direction_mismatch=16, vwap_side=2; dominant buckets: unclear_but_constructive=16, possible_reversal_onset=2.
- Fact: `2026-04-19` accepted `0`, rejects `22`, interesting rejects `18`, close outcomes `0`; top reject reasons: direction_mismatch=9, vwap_side=6; dominant buckets: unclear_but_constructive=13, possible_continuation_pressure=3.
- Fact: `2026-04-20` accepted `0`, rejects `19`, interesting rejects `16`, close outcomes `0`; top reject reasons: vwap_side=8, direction_mismatch=6; dominant buckets: unclear_but_constructive=11, possible_trap_or_false_break=2.
- Fact: `2026-04-21` accepted `1`, rejects `16`, interesting rejects `12`, close outcomes `1`; top reject reasons: direction_mismatch=9, chop_coh=2; dominant buckets: unclear_but_constructive=10, possible_reversal_confirmation=1.
- Fact: `2026-04-22` accepted `1`, rejects `13`, interesting rejects `11`, close outcomes `1`; top reject reasons: direction_mismatch=5, vwap_side=4; dominant buckets: unclear_but_constructive=11.
- Fact: `2026-04-23` accepted `1`, rejects `17`, interesting rejects `12`, close outcomes `1`; top reject reasons: direction_mismatch=10, 3of3_fail=3; dominant buckets: unclear_but_constructive=10, possible_reversal_onset=1.
- Fact: `2026-04-24` accepted `0`, rejects `18`, interesting rejects `0`, close outcomes `0`; top reject reasons: direction_mismatch=8, vwap_side=6; dominant buckets: none visible.
- Fact: `2026-04-25` accepted `0`, rejects `16`, interesting rejects `0`, close outcomes `0`; top reject reasons: direction_mismatch=11, 3of3_fail=2; dominant buckets: none visible.
- Fact: `2026-04-26` accepted `1`, rejects `17`, interesting rejects `0`, close outcomes `1`; top reject reasons: direction_mismatch=12, vwap_side=2; dominant buckets: none visible.
- Fact: `2026-04-27` accepted `0`, rejects `19`, interesting rejects `0`, close outcomes `0`; top reject reasons: direction_mismatch=9, vwap_side=5; dominant buckets: none visible.
- Fact: `2026-04-28` accepted `1`, rejects `19`, interesting rejects `0`, close outcomes `0`; top reject reasons: direction_mismatch=9, 3of3_fail=4; dominant buckets: none visible.
- Fact: `2026-04-29` accepted `0`, rejects `18`, interesting rejects `0`, close outcomes `1`; top reject reasons: vwap_side=8, direction_mismatch=7; dominant buckets: none visible.
- Fact: `2026-04-30` accepted `0`, rejects `14`, interesting rejects `0`, close outcomes `0`; top reject reasons: direction_mismatch=7, 3of3_fail=3; dominant buckets: none visible.
- Fact: `2026-05-01` accepted `0`, rejects `16`, interesting rejects `0`, close outcomes `0`; top reject reasons: direction_mismatch=9, vwap_side=4; dominant buckets: none visible.
- Fact: `2026-05-02` accepted `0`, rejects `15`, interesting rejects `0`, close outcomes `0`; top reject reasons: direction_mismatch=11, vwap_side=2; dominant buckets: none visible.

### 2) Accepted events
- Fact: `2026-04-09 17:35:00` long PEAK_EMIT price `72028.45`; cum_delta_24h `1046.12`, cum_delta_180m `2936.47`, cum_delta_60m `338.02`, ret_15m `-240.60`, ret_60m `245.20`, vwap_side `above`; OI `93105.06`, funding `-1.937e-05`, liq_buy `0.0`, liq_sell `0.312`; no joined close outcome.
- Fact: `2026-04-11 15:11:00` short PEAK_EMIT price `72640.74`; cum_delta_24h `2267.17`, cum_delta_180m `-1150.06`, cum_delta_60m `143.66`, ret_15m `-31.10`, ret_60m `-15.40`, vwap_side `below`; OI `97559.34`, funding `-7.157e-05`, liq_buy `0.0`, liq_sell `0.0`; no joined close outcome.
- Fact: `2026-04-12 03:36:00` short PEAK_EMIT price `72386.79`; cum_delta_24h `2907.12`, cum_delta_180m `-305.92`, cum_delta_60m `-105.25`, ret_15m `35.40`, ret_60m `-191.70`, vwap_side `below`; OI `96366.77`, funding `-7.9e-05`, liq_buy `0.0`, liq_sell `0.0`; no joined close outcome.
- Fact: `2026-04-16 15:53:00` short PEAK_EMIT price `74030.86`; cum_delta_24h `2258.17`, cum_delta_180m `-143.57`, cum_delta_60m `558.26`, ret_15m `-207.70`, ret_60m `671.30`, vwap_side `below`; OI `97558.11`, funding `-2.764e-05`, liq_buy `0.179`, liq_sell `0.0`; no joined close outcome.
- Fact: `2026-04-17 10:49:00` long PEAK_EMIT price `75585.54`; cum_delta_24h `5049.38`, cum_delta_180m `3413.82`, cum_delta_60m `-936.09`, ret_15m `7.40`, ret_60m `-486.70`, vwap_side `above`; OI `99209.57`, funding `4.097e-05`, liq_buy `0.0`, liq_sell `0.0`; close `window_match/SL` side `LONG` entry `75603.54`.
- Fact: `2026-04-21 10:48:00` long PEAK_EMIT price `76739.50`; cum_delta_24h `7829.54`, cum_delta_180m `2229.04`, cum_delta_60m `510.67`, ret_15m `150.30`, ret_60m `394.00`, vwap_side `above`; OI `94997.33`, funding `-5.624e-05`, liq_buy `3.874`, liq_sell `0.0`; close `window_match/SL` side `LONG` entry `76767.94`.
- Fact: `2026-04-22 04:12:00` long PEAK_EMIT price `76706.72`; cum_delta_24h `2823.82`, cum_delta_180m `2315.13`, cum_delta_60m `-244.05`, ret_15m `62.00`, ret_60m `-44.90`, vwap_side `above`; OI `98690.79`, funding `-6.56e-06`, liq_buy `0.09`, liq_sell `0.0`; no joined close outcome.
- Fact: `2026-04-23 10:45:00` short PEAK_EMIT price `77729.14`; cum_delta_24h `3103.28`, cum_delta_180m `-4475.85`, cum_delta_60m `-3681.74`, ret_15m `-12.30`, ret_60m `-354.80`, vwap_side `below`; OI `97729.86`, funding `-1.558e-05`, liq_buy `0.0`, liq_sell `0.0`; close `window_match/SL` side `SHORT` entry `77774.32`.
- Fact: `2026-04-26 07:13:00` long PEAK_EMIT price `78004.63`; cum_delta_24h `0.00`, cum_delta_180m `0.00`, cum_delta_60m `0.00`, ret_15m `0.00`, ret_60m `0.00`, vwap_side `above`; OI `95749.48`, funding `-8.73e-05`, liq_buy `0.0`, liq_sell `0.0`; no joined close outcome.
- Fact: `2026-04-28 09:17:00` short PEAK_EMIT price `76474.42`; cum_delta_24h `0.00`, cum_delta_180m `0.00`, cum_delta_60m `0.00`, ret_15m `0.00`, ret_60m `0.00`, vwap_side `below`; OI `98842.91`, funding `-8.73e-05`, liq_buy `0.0`, liq_sell `0.0`; no joined close outcome.

### 3) Key rejects
- Fact: `2026-04-09 13:27:00` short CANDIDATE_COMPARISON_REJECT price `71061.21`; cum_delta_24h `-3897.78`, cum_delta_180m `-756.32`, cum_delta_60m `-105.85`, ret_15m `-14.60`, ret_60m `-34.10`, vwap_side `below`; reject_reason `3of3_fail`, bucket `possible_reversal_confirmation`, rule `IR_B1`; with visible 24h cumulative-delta regime
- Fact: `2026-04-12 03:35:00` short CANDIDATE_COMPARISON_REJECT price `72717.00`; cum_delta_24h `2886.61`, cum_delta_180m `-323.75`, cum_delta_60m `-102.29`, ret_15m `-5.00`, ret_60m `-225.10`, vwap_side `below`; reject_reason `3of3_fail`, bucket `possible_reversal_confirmation`, rule `IR_B1`; against visible 24h cumulative-delta regime
- Fact: `2026-04-15 15:32:00` short CANDIDATE_COMPARISON_REJECT price `74232.53`; cum_delta_24h `-458.22`, cum_delta_180m `-1650.15`, cum_delta_60m `-1654.37`, ret_15m `-517.40`, ret_60m `-784.40`, vwap_side `below`; reject_reason `3of3_fail`, bucket `possible_reversal_confirmation`, rule `IR_B1`; with visible 24h cumulative-delta regime
- Fact: `2026-04-08 16:33:00` short CANDIDATE_COMPARISON_REJECT price `71192.64`; cum_delta_24h `16818.51`, cum_delta_180m `-3021.25`, cum_delta_60m `-557.54`, ret_15m `-9.90`, ret_60m `77.20`, vwap_side `above`; reject_reason `vwap_side`, bucket `possible_reversal_confirmation`, rule `IR_B1`; against visible 24h cumulative-delta regime
- Fact: `2026-04-11 22:41:00` short CANDIDATE_COMPARISON_REJECT price `73316.37`; cum_delta_24h `3650.30`, cum_delta_180m `-544.50`, cum_delta_60m `-190.62`, ret_15m `-132.60`, ret_60m `-166.40`, vwap_side `above`; reject_reason `vwap_side`, bucket `possible_reversal_confirmation`, rule `IR_B1`; against visible 24h cumulative-delta regime
- Fact: `2026-04-11 23:50:00` short CANDIDATE_COMPARISON_REJECT price `73447.50`; cum_delta_24h `3518.44`, cum_delta_180m `-133.69`, cum_delta_60m `-35.38`, ret_15m `-45.50`, ret_60m `-265.30`, vwap_side `above`; reject_reason `vwap_side`, bucket `possible_reversal_confirmation`, rule `IR_B1`; against visible 24h cumulative-delta regime
- Fact: `2026-04-15 06:20:00` short CANDIDATE_COMPARISON_REJECT price `74355.78`; cum_delta_24h `7917.97`, cum_delta_180m `-622.27`, cum_delta_60m `-608.26`, ret_15m `55.10`, ret_60m `-232.10`, vwap_side `below`; reject_reason `3of3_fail`, bucket `possible_continuation_pressure`, rule `IR_C2`; against visible 24h cumulative-delta regime
- Fact: `2026-04-15 09:09:00` short CANDIDATE_COMPARISON_REJECT price `73847.72`; cum_delta_24h `6656.47`, cum_delta_180m `179.42`, cum_delta_60m `348.97`, ret_15m `-126.40`, ret_60m `246.00`, vwap_side `below`; reject_reason `3of3_fail`, bucket `possible_trap_or_false_break`, rule `IR_E2`; against visible 24h cumulative-delta regime

### 4) Focused comparison
- Fact: accepted reference: `2026-04-09 17:35:00` long PEAK_EMIT price `72028.45`; cum_delta_24h `1046.12`, cum_delta_180m `2936.47`, cum_delta_60m `338.02`, ret_15m `-240.60`, ret_60m `245.20`, vwap_side `above`.
- Fact: rejected comparator: `2026-04-09 13:27:00` short CANDIDATE_COMPARISON_REJECT price `71061.21`; cum_delta_24h `-3897.78`, cum_delta_180m `-756.32`, cum_delta_60m `-105.85`, ret_15m `-14.60`, ret_60m `-34.10`, vwap_side `below`; blocker `3of3_fail` bucket `possible_reversal_confirmation`.
- Interpretation: the comparison is partial; accepted and rejected rows expose regime/setup/timing fields, but reject rows do not expose hidden downstream gate internals beyond visible `reject_reason` and bucket labels.

### 5) Batch-level conclusion
- Fact: batch totals are `10` accepted events, `495` rejects, `290` interesting rejects, and `8` close-outcome rows; accepted-to-close `window_match` count is `3`.
- Fact: dominant reject reasons are direction_mismatch=255, vwap_side=123, 3of3_fail=52, vwap_distance=34, chop_coh=15.
- Fact: dominant interesting buckets are unclear_but_constructive=228, possible_reversal_onset=18, possible_reversal_confirmation=18, possible_trap_or_false_break=13, possible_continuation_pressure=10.
- Interpretation: `vwap_side` remains a material blocker because it appears repeatedly among visible reject reasons, but it does not by itself prove the rejected cases are weak.
- Hypothesis: next research should isolate `vwap_side` and `direction_mismatch` rejects with strong same-direction cumulative-delta context, then compare them against accepted PEAK reference rows.

## Part 2 - Analytical memo

### A. Batch verdict
- Fact: this is a reject-heavy batch: `495` rejects versus `10` accepted rows.
- Interpretation: the research center of gravity is reject taxonomy and blocker diagnostics, not accepted-flow validation.
- Unknown: profitability or edge cannot be inferred from this evidence because accepted outcomes are sparse and joined close outcomes are rarer than accepted rows.

### B. Strongest evidence clusters
- Fact: `direction_mismatch` repeats `255` times. Interpretation: this is a durable blocker cluster worth separating by 24h regime alignment, 180m transition, 60m pressure, and entry timing fields.
- Fact: `vwap_side` repeats `123` times. Interpretation: this is a durable blocker cluster worth separating by 24h regime alignment, 180m transition, 60m pressure, and entry timing fields.
- Fact: `3of3_fail` repeats `52` times. Interpretation: this is a durable blocker cluster worth separating by 24h regime alignment, 180m transition, 60m pressure, and entry timing fields.
- Fact: `vwap_distance` repeats `34` times. Interpretation: this is a durable blocker cluster worth separating by 24h regime alignment, 180m transition, 60m pressure, and entry timing fields.
- Fact: bucket `unclear_but_constructive` repeats `228` times. Hypothesis: the label may contain multiple subgroups; it is research material, not a validated setup class.
- Fact: bucket `possible_reversal_onset` repeats `18` times. Hypothesis: the label may contain multiple subgroups; it is research material, not a validated setup class.
- Fact: bucket `possible_reversal_confirmation` repeats `18` times. Hypothesis: the label may contain multiple subgroups; it is research material, not a validated setup class.

### C. Structural paradoxes and tensions
- Interpretation: some rejected rows show stronger local cumulative-delta pressure than accepted reference rows, but visible blockers such as `vwap_side` or `direction_mismatch` prevent treating them as equivalent accepted candidates.
- Fact: accepted rows include both complete `cum_delta_24h` regime fields and sparse joined close outcomes; this supports regime-aware comparison but not outcome validation.
- Fact: `interesting_rejects` is empty for `2026-04-24, 2026-04-25, 2026-04-26, 2026-04-27, 2026-04-28, 2026-04-29, 2026-04-30, 2026-05-01, 2026-05-02`. Unknown: whether this reflects a real absence of interesting buckets or a heuristic coverage shift in the review package.
- Unknown: deeper failure opacity remains for `3of3_fail` and comparison rejects because the review files expose terminal labels but not every intermediate scoring path.

### D. Expanded key case notes
- Fact: `2026-04-09 17:35:00` accepted, `long`. Metrics: cum_delta_24h `1046.12`, cum_delta_180m `2936.47`, cum_delta_60m `338.02`, ret_15m `-240.60`, ret_60m `245.20`. with visible 24h cumulative-delta regime
  - Blocker status: deeper failure opaque from current files.
  - Sequence note: see selected-case sequence context CSV for same-session nearby rows; this markdown does not infer sequence relations beyond that artifact.
- Fact: `2026-04-11 15:11:00` accepted, `short`. Metrics: cum_delta_24h `2267.17`, cum_delta_180m `-1150.06`, cum_delta_60m `143.66`, ret_15m `-31.10`, ret_60m `-15.40`. against visible 24h cumulative-delta regime
  - Blocker status: deeper failure opaque from current files.
  - Sequence note: see selected-case sequence context CSV for same-session nearby rows; this markdown does not infer sequence relations beyond that artifact.
- Fact: `2026-04-12 03:36:00` accepted, `short`. Metrics: cum_delta_24h `2907.12`, cum_delta_180m `-305.92`, cum_delta_60m `-105.25`, ret_15m `35.40`, ret_60m `-191.70`. against visible 24h cumulative-delta regime
  - Blocker status: deeper failure opaque from current files.
  - Sequence note: see selected-case sequence context CSV for same-session nearby rows; this markdown does not infer sequence relations beyond that artifact.
- Fact: `2026-04-16 15:53:00` accepted, `short`. Metrics: cum_delta_24h `2258.17`, cum_delta_180m `-143.57`, cum_delta_60m `558.26`, ret_15m `-207.70`, ret_60m `671.30`. against visible 24h cumulative-delta regime
  - Blocker status: deeper failure opaque from current files.
  - Sequence note: see selected-case sequence context CSV for same-session nearby rows; this markdown does not infer sequence relations beyond that artifact.
- Fact: `2026-04-17 10:49:00` accepted, `long`. Metrics: cum_delta_24h `5049.38`, cum_delta_180m `3413.82`, cum_delta_60m `-936.09`, ret_15m `7.40`, ret_60m `-486.70`. with visible 24h cumulative-delta regime
  - Blocker status: deeper failure opaque from current files.
  - Sequence note: see selected-case sequence context CSV for same-session nearby rows; this markdown does not infer sequence relations beyond that artifact.

### D2. Case-comparison discipline
- Fact: direct comparisons must include `cum_delta_24h`; all selected rows in this package expose that field unless explicitly blank in the CSV.
- Interpretation: a rejected case can be called structurally stronger only on named metrics such as larger absolute `cum_delta_180m`, cleaner same-side `cum_delta_60m`, or more favorable `ret_60m`; blocker labels still limit equivalence.
- Unknown: hidden blocker decomposition and true counterfactual acceptance remain unavailable from the daily review files.

### E. Accepted vs rejected reference-class judgment
- Fact: accepted PEAK rows show the narrow survival path through the current funnel; they do not prove broad edge or profitability.
- Interpretation: rejects are at least as important as accepted rows for this batch because reject volume and repeated blocker patterns dominate the evidence.
- Unknown: whether any rejected row is truly superior to accepted reference class requires blocker-level reconstruction and more joined close outcomes.

### F. What remains unknown
- Unknown: sparse accepted sample and sparse joined outcomes prevent outcome-strength conclusions.
- Unknown: enriched-field separation is incomplete without comparing blocker-specific cohorts over a larger window.
- Unknown: sequence/transition ambiguity remains unless the sequence context and raw-feed micro extracts are inspected case by case.

### G. Next best research direction
- Hypothesis: isolate `vwap_side` rejects with strong same-direction `cum_delta_24h`, `cum_delta_180m`, and `cum_delta_60m` alignment.
- Hypothesis: compare `direction_mismatch` rejects that also carry reversal-like buckets against later same-session accepted rows.
- Hypothesis: inspect whether `unclear_but_constructive` contains separable subgroups by 24h regime and ret_60m follow-through.
- Hypothesis: use M2.6 chain candidates to distinguish isolated rejects from process-chain clusters before proposing any filter change.
