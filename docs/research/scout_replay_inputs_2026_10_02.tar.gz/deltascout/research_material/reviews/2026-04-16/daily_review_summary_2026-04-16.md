# Daily Review Summary 2026-04-16

- processed_date: 2026-04-16
- accepted_row_count: 1
- reject_row_count: 22
- interesting_reject_row_count: 21
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-04-16.csv
- reject_reason_summary_group_count: 5
- reject_counts_by_reason:
  - 3of3_fail: 1
  - direction_mismatch: 12
  - vwap_side: 9
- files_created:
  - accepted_event_context_2026-04-16.csv
  - reject_event_context_2026-04-16.csv
  - interesting_rejects_2026-04-16.csv
  - reject_reason_summary_2026-04-16.csv
  - daily_review_summary_2026-04-16.md
