# Fast Money Pre-Impulse Table Summary

scope: `2026-03-17_to_2026-08-18`
rows: `492`
fast_money_trigger_rows: `96`

## Proxy Kinds

- `best_proxy`: 246
- `earliest_proxy`: 246

## Candidate Families

- `FAST_MONEY_COUNTERTREND_IMPULSE`: 243
- `FAST_MONEY_LONG_FORERUNNER`: 81
- `FAST_MONEY_LONG_PRE_IMPULSE`: 40
- `FAST_MONEY_SHORT_LATE_RISK`: 27
- `FAST_MONEY_SHORT_PRE_IMPULSE`: 101

## Phase Labels

- `acceleration_trigger`: 75
- `countertrend_impulse`: 243
- `early_watch`: 66
- `late_after_impulse`: 27
- `reversal_forerunner`: 81

## Use

This table is an event-study surface for pre-impulse / fast-money research, not a live signal spec.
Use it to compare early watch vs lower-adverse trigger timing, stop survival, and PEAK delay.
