"""Run from project root. Immutable, local-only May 4 clock correction replay."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
from pathlib import Path

from deltascout.research_bundle.scout_backtester.cli import build_parser, run


MATERIAL = Path('deltascout/research_material')
AUDIT = Path(__file__).resolve().parent
RECOVERY = MATERIAL / 'recovery_clock_v2_2026-09-08'
FROZEN = MATERIAL / 'source_archives/vps_refresh_2026-08-26/effective_feed_merged'
EFFECTIVE = RECOVERY / 'effective_feed'
BACKTESTS = MATERIAL / 'backtests'
OLD_PREFIX = 'scout_peak_v8_btcusdt_structural_selection_to_btcusdc_execution'
NEW_PREFIX = 'scout_peak_v8_clock_corrected_2026-09-08'
START, END = '2026-04-23 17:05:00', '2026-05-06 22:51:00'


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        return reader.fieldnames, list(reader)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare_effective():
    if EFFECTIVE.exists():
        manifest = json.loads((RECOVERY/'effective_feed_manifest.json').read_text())
        for item in manifest['files']:
            assert sha(Path(item['source'])) == item['source_sha256']
            assert sha(Path(item['output'])) == item['output_sha256']
        print('verified existing immutable effective feed', flush=True)
        return
    EFFECTIVE.mkdir(parents=True)
    records = []
    counts = dict(outside_gap_rows_checked=0, changed_gap_rows=0, added_gap_rows=0,
                  removed_gap_rows=0, unchanged_daily_files=0, rebuilt_daily_files=0)
    for source in sorted(FROZEN.glob('*.csv')):
        target = EFFECTIVE / source.name
        replacement = RECOVERY / 'recovered_feed' / source.name
        original_hash = sha(source)
        if not replacement.exists():
            shutil.copyfile(source, target)
            assert sha(target) == original_hash
            counts['unchanged_daily_files'] += 1
        else:
            fields, original = read_csv(source)
            _, recovered = read_csv(replacement)
            original_map = {r['Timestamp']: r for r in original}
            recovered_map = {r['Timestamp']: {k: r.get(k, '') for k in fields}
                             for r in recovered if START <= r['Timestamp'] <= END}
            output = {t: r for t, r in original_map.items() if not START <= t <= END}
            output.update(recovered_map)
            for t, r in original_map.items():
                if not START <= t <= END:
                    assert output[t] == r
                    counts['outside_gap_rows_checked'] += 1
                elif t not in output:
                    counts['removed_gap_rows'] += 1
                elif output[t] != r:
                    counts['changed_gap_rows'] += 1
            counts['added_gap_rows'] += len(set(recovered_map).difference(original_map))
            with target.open('w', encoding='utf-8', newline='') as handle:
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                writer.writerows(output[t] for t in sorted(output))
            counts['rebuilt_daily_files'] += 1
        assert sha(source) == original_hash
        records.append(dict(source=str(source), source_sha256=original_hash,
                            output=str(target), output_sha256=sha(target)))
    manifest = dict(recovery_manifest=str(RECOVERY/'quality/recovery_manifest.json'),
                    recovery_manifest_sha256=sha(RECOVERY/'quality/recovery_manifest.json'),
                    policy='replace only UTC gap rows; preserve frozen rows outside gap',
                    counts=counts, files=records)
    (RECOVERY/'effective_feed_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
    print('effective feed:', counts, flush=True)


def replay_baselines():
    commands = []
    for suffix, policy in [('', 'NONE'), ('_live_ab', 'UNION_A_OR_B')]:
        previous = BACKTESTS / f'{OLD_PREFIX}{suffix}_trailing_parity_v2' / 'run_manifest.json'
        old = json.loads(previous.read_text())
        experiment_id = NEW_PREFIX + suffix
        argv = [
            '--candidate-root', str(MATERIAL/'reviews'),
            '--raw-archive-root', str(MATERIAL/'raw_archive'),
            '--feed-root', str(EFFECTIVE),
            '--execution-feed-root', str(MATERIAL/'execution_feed/btcusdc_spot_1m/daily'),
            '--quality-sidecar-root', str(RECOVERY/'quality'),
            '--server-state-root', str(MATERIAL/'server_state'),
            '--output-root', str(BACKTESTS),
            '--date-from', '2026-03-20', '--date-to', '2026-08-25',
            '--candidate-groups', 'PEAK_EMIT_BASELINE',
            '--candidate-loss-filter', policy,
            '--fill-model', 'LIMIT_THEN_MARKET_90S_GUARDED_V0_1',
            '--initial-stop-policy', 'volume_confirmed_swing',
            '--initial-swing-price-source', 'extreme',
            '--initial-swing-lr', '25', '--initial-swing-buffer-usd', '50',
            '--initial-swing-max-distance-usd', '1200', '--initial-swing-require-full-window',
            '--swing-lookback-minutes', '1440', '--commission-rate', '0.000744',
            '--fixed-notional-usdc', '3000', '--entry-slippage-bps', '0',
            '--exit-slippage-bps', '1', '--stop-slippage-bps', '2',
            '--experiment-id', experiment_id,
            '--description', 'V8 baseline with UTC-correct legacy recovery, completed-minute spot availability, and post-fill stop invariant; strategy parameters unchanged',
        ]
        print('starting', experiment_id, flush=True)
        output = BACKTESTS/experiment_id/'run_manifest.json'
        if not output.exists():
            output = run(build_parser().parse_args(argv))
        new = json.loads(output.read_text())
        assert new['resolved_config']['description'] == argv[-1]
        for item in new['input_files']:
            assert sha(Path(item['path'])) == item['sha256']
        differences = {k: [v, new['resolved_config'][k]] for k, v in old['resolved_config'].items()
                       if v != new['resolved_config'][k]}
        assert set(differences) <= {'experiment_id', 'description', 'conversion_model_id'}, differences
        assert old['date_range'] == new['date_range']
        commands.append(dict(argv=argv, old_manifest=str(previous), new_manifest=str(output),
                             config_differences=differences))
        print('completed', experiment_id, 'candidates', new['candidate_count'], flush=True)
        (AUDIT/'baseline_runs.json').write_text(json.dumps(commands, indent=2)+'\n', encoding='utf-8')


if __name__ == '__main__':
    prepare_effective()
    replay_baselines()
