# OI shadow-policy and runtime alignment decision

## Decision

Do not deploy `oi_change_240m < 0` as a hard veto or as an automatic live penalty.
The corrected local-to-UTC join shows that 240-minute OI decline is common in both
plain losses and protected profitable trades. Keep OI as a descriptive shadow
feature, measure its incremental value prospectively, and leave order admission
unchanged.

## Timestamp correction

- DeltaScout event timestamps are Europe/Bratislava local-naive.
- `effective_feed` timestamps are UTC-naive.
- The earlier commonality report compared them without conversion and selected
  feed rows two hours after summer-time events.
- The builder now converts the event cutoff to UTC before calculating 15m, 60m,
  and 240m feed features.

Corrected prevalence:

| Feature | Plain losses | Protected controls | Exploratory Fisher p |
|---|---:|---:|---:|
| `oi_change_60m < 0` | 10/17 | 2/7 | 0.371 |
| `oi_change_240m < 0` | 11/17 | 4/7 | 1.000 |

This removes the earlier apparent `9/17 versus 0/7` separation for OI 240m.

## Latest protected trade counterexample

Trade `EX_EN_1787063409`, long, signal `2026-08-18 16:30:00` Bratislava
(`2026-08-18 14:30:00Z`):

| Measure | Value |
|---|---:|
| OI change 15m | -404.51 |
| OI change 60m | -749.92 |
| OI change 240m | -725.78 |
| Price change 240m | +1.286% |
| Buy/sell delta 240m | +3318.027 |
| LLM verdict | REJECT, confidence 0.74 |
| Lifecycle | TP1, TP2, trailing stop |

Using actual entry `64943.67` and the initial stop `63989.78`, initial risk was
`953.89`. The legs produced approximately `1.059R`, `2.088R`, and `4.368R` at
TP1, TP2, and the final trailing stop. Their unweighted leg sum is `7.515R`,
which matches the operator's “7R” convention. With equal one-third sizing the
whole-position gross result is approximately `2.505R` before fees.

This is a direct false-reject example and a direct counterexample to an OI-down
hard veto. Falling OI during an up move can describe short-covering, but a
short-covering move can still deliver a large long payoff.

## Current LLM calibration evidence

Among trades with an LLM verdict and a comparable outcome:

| Outcome | Count | SUPPORT | UNCLEAR | REJECT |
|---|---:|---:|---:|---:|
| Plain stop loss | 8 | 5 | 0 | 3 |
| Protected profit | 5 | 2 | 2 | 1 |
| TP1 then stop | 4 | 3 | 1 | 0 |

The three latest August plain losses were all REJECT, but the next protected
profit was also REJECT. Therefore the recent behavior is promising for loss
detection but is not yet safe as an execution gate.

## Shadow implementation contract

For every primary or blocked-by-active-position DeltaScout signal, journal:

- `oi_change_15m`, `oi_change_60m`, `oi_change_240m`;
- directional price change for the same windows;
- directional buy/sell delta for the same windows;
- data-quality flags and normalized UTC cutoff;
- a descriptive OI participation label, not a verdict override:
  `POSITION_BUILD`, `DIRECTIONAL_MOVE_WITH_OI_DOWN`, `COUNTER_DIRECTION_OI_DOWN`,
  `NEUTRAL`, or `DATA_QUALITY_GAP`;
- LLM verdict, confidence, model version, active-position state, candidate-entry
  improvement, and eventual hypothetical outcome.

The OI label must not modify entry admission, order size, stop, or exits during
the shadow phase. Evaluation should compare the LLM alone with LLM plus OI label
and report both avoided losses and rejected protected profits.

## Runtime/Git alignment

- VPS `/root/volume-alert` is not a Git checkout.
- VPS `executor.py` and `executor_mod/llm_trade_judge.py` are byte-for-byte equal
  to the staged server snapshots.
- Those snapshots have no content diff from GitHub `origin/v2.0` at commit
  `d51f644`.
- The current local checkout is `research-delta-analizer` at `103b3d2`, aligned
  with its own remote, but it is a separate reset history and is not the correct
  base for runtime deployment.

Safe sequence:

1. Create an isolated branch/worktree from `origin/v2.0`.
2. Apply the blocked-signal shadow journal changes there as a separate commit.
3. Add OI participation journaling as a second, behavior-neutral commit.
4. Run targeted tests and compare the runtime files against `origin/v2.0`.
5. Back up the two VPS runtime files.
6. Deploy only the two reviewed files, without tests or research artifacts.
7. Restart the executor and verify one synthetic/offline shadow record before
   enabling live shadow collection.

Server writes, deployment, and restart require a separate production-adjacent
approval. No server file was changed while producing this decision.
