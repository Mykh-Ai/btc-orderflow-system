"""Read-only server audit for the entry-time LLM judge."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone


def run(args):
    p = subprocess.run(args, capture_output=True, text=True)
    return {"exit": p.returncode, "stdout": p.stdout, "stderr": p.stderr[:1200]}


out = {"audit_utc": datetime.now(timezone.utc).isoformat()}
ins = run(["docker", "inspect", "executor"])
if ins["exit"] == 0:
    obj = json.loads(ins["stdout"])[0]
    env = dict(x.split("=", 1) for x in obj["Config"]["Env"] if "=" in x)
    names = {
        "LLM_TRADE_JUDGE_ENABLED", "LLM_TRADE_JUDGE_MODE", "LLM_TRADE_JUDGE_MODEL",
        "LLM_TRADE_JUDGE_TIMEOUT_SEC", "LLM_TRADE_JUDGE_MAX_RETRIES",
        "LLM_TRADE_JUDGE_MAX_OUTPUT_TOKENS", "LLM_TRADE_JUDGE_NOTIFY_TELEGRAM",
        "LLM_TRADE_JUDGE_CONTEXT_ENABLED", "LLM_TRADE_JUDGE_CONTEXT_LOOKBACK_HOURS",
        "LLM_TRADE_JUDGE_CONTEXT_MAX_EVENTS", "LLM_TRADE_JUDGE_DELTASCOUT_LOG",
        "LLM_TRADE_JUDGE_AGG_CSV", "LLM_TRADE_JUDGE_FEED_TIMEZONE",
        "LLM_TRADE_JUDGE_MARKET_MONITOR_SNAPSHOT_ENABLED",
        "LLM_TRADE_JUDGE_MARKET_MONITOR_CURRENT_FEED",
        "LLM_TRADE_JUDGE_MARKET_MONITOR_CONTEXT_FEED",
        "LLM_TRADE_JUDGE_MARKET_MONITOR_MAX_ZONES", "SYMBOL", "TRADE_MODE",
        "TRAIL_SOURCE", "TRAIL_SWING_LOOKBACK", "TRAIL_SWING_LR", "TRAIL_SWING_BUFFER_USD",
        "TRAIL_STEP_USD", "TRAIL_CONFIRM_BUFFER_USD", "INITIAL_STOP_POLICY",
        "INITIAL_SWING_LOOKBACK", "INITIAL_SWING_LR", "INITIAL_SWING_BUFFER_USD",
        "INITIAL_SWING_MAX_DISTANCE_USD", "INITIAL_SWING_REQUIRE_FULL_WINDOW",
    }
    out["container"] = {
        "image": obj["Image"], "started_at": obj["State"]["StartedAt"],
        "status": obj["State"]["Status"], "restart_count": obj["RestartCount"],
        "env": {k: env[k] for k in sorted(names) if k in env},
        "mounts": [{k: m.get(k) for k in ("Source", "Destination", "RW")} for m in obj["Mounts"]],
    }

remote_code = r'''import hashlib,json
from pathlib import Path
root=Path("/app")
out={"files":{}}
paths=[root/"executor.py"]+sorted((root/"executor_mod").glob("*.py"))+sorted((root/"market_monitor").rglob("*.py"))
for p in paths:
 if p.is_file():
  b=p.read_bytes();out["files"][str(p)]={"sha256":hashlib.sha256(b).hexdigest(),"size":len(b),"mtime":p.stat().st_mtime}
p=root/"executor_mod/llm_trade_judge.py"; lines=p.read_text(encoding="utf-8-sig").splitlines()
def block(name):
 starts=[i for i,x in enumerate(lines) if x.startswith("def "+name+"(")]
 if not starts:return None
 a=starts[0]; b=min(len(lines),a+260)
 for i in range(a+1,len(lines)):
  if lines[i].startswith("def "): b=i;break
 return {"start_line":a+1,"end_line":b,"text":"\\n".join(lines[a:b])}
out["judge"]={"sha256":out["files"][str(p)]["sha256"],"size":out["files"][str(p)]["size"]}
for name in ["build_llm_trade_judge_prompt","_json_schema","build_pretrade_evidence_pack","build_market_monitor_snapshot_until_cutoff","maybe_record_llm_pretrade_judge"]: out[name]=block(name)
out["prompt_markers"]={m:[i+1 for i,x in enumerate(lines) if m in x][:20] for m in ["Judge only","Do not infer future outcome","market_monitor_snapshot","execution_geometry","trailing","SL","TP"]}
print(json.dumps(out,ensure_ascii=True))'''
code = run(["docker", "exec", "executor", "python", "-c", remote_code])
out["container_code"] = json.loads(code["stdout"]) if code["exit"] == 0 else code

journal = run(["docker", "exec", "executor", "python", "-c", r'''import json
from pathlib import Path
p=Path("/data/state/llm_trade_verdicts.jsonl")
rows=[json.loads(x) for x in p.read_text().splitlines() if x.strip()] if p.exists() else []
print(json.dumps({"exists":p.exists(),"count":len(rows),"mtime":p.stat().st_mtime if p.exists() else None,"last":rows[-3:]},ensure_ascii=True))'''])
out["journal"] = json.loads(journal["stdout"]) if journal["exit"] == 0 else journal
print(json.dumps(out, ensure_ascii=True))
