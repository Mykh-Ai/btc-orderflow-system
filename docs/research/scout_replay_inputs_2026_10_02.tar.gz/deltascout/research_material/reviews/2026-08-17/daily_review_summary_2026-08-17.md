# Daily Review Summary 2026-08-17

- processed_date: 2026-08-17
- accepted_row_count: 0
- reject_row_count: 16
- interesting_reject_row_count: 14
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-08-17.csv
- reject_reason_summary_group_count: 6
- reject_counts_by_reason:
  - chop_coh: 1
  - direction_mismatch: 7
  - imb_band: 1
  - vwap_side: 7
- files_created:
  - accepted_event_context_2026-08-17.csv
  - reject_event_context_2026-08-17.csv
  - interesting_rejects_2026-08-17.csv
  - reject_reason_summary_2026-08-17.csv
  - daily_review_summary_2026-08-17.md
