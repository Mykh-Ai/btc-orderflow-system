"""Reconcile frozen/live evidence and new offline outputs; run from repo root."""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from dataclasses import replace
from datetime import timedelta
from pathlib import Path

from deltascout.research_bundle.scout_backtester.candidate_compiler import compile_candidates
from deltascout.research_bundle.scout_backtester.contracts import BacktestContractError, ReplayConfig
from deltascout.research_bundle.scout_backtester.execution_policy import build_execution_plan
from deltascout.research_bundle.scout_backtester.feed_loader import load_feed
from deltascout.research_bundle.scout_backtester.fill_models import find_entry_fill
from deltascout.research_bundle.scout_backtester.replay_engine import replay_candidate


B = Path('deltascout/research_material')
OUT = Path(__file__).resolve().parent
CID = 'SCOUT_fb0782c502d88b2b0e08'
OLD = 'scout_peak_v8_btcusdt_structural_selection_to_btcusdc_execution'
NEW = 'scout_peak_v8_clock_corrected_2026-09-08'


def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write_json(path, payload):
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str)+'\n', encoding='utf-8')


def statistics(trades):
    fills = [r for r in trades if r['entry_status'] == 'FILLED']
    equity, peak, drawdown = 0., 0., 0.
    for r in sorted(fills, key=lambda r: (r['exit_ts'], r['trade_id'])):
        equity += float(r['net_pnl_usdc'])
        peak = max(peak, equity)
        drawdown = max(drawdown, peak-equity)
    wins = sum(max(0., float(r['net_pnl_usdc'])) for r in fills)
    losses = -sum(min(0., float(r['net_pnl_usdc'])) for r in fills)
    bad = [r['candidate_id'] for r in fills if not (
        float(r['initial_stop_price']) < float(r['entry_fill_price']) if r['side'] == 'LONG'
        else float(r['initial_stop_price']) > float(r['entry_fill_price']))]
    return dict(candidate_count=len(trades), filled_count=len(fills), net_usdc=equity,
                profit_factor=wins/losses if losses else None, max_drawdown_usdc=drawdown,
                lifecycle_counts=dict(Counter(r['lifecycle_class'] for r in fills)),
                wrong_side_initial_stop_candidate_ids=bad,
                nonnegative_plain_sl_candidate_ids=[r['candidate_id'] for r in fills
                    if r['lifecycle_class'] == 'PLAIN_SL' and float(r['gross_pnl_usdc']) >= 0])


def audit_baselines():
    comparisons, changed = {}, []
    for suffix in ['', '_live_ab']:
        old_dir = B/'backtests'/f'{OLD}{suffix}_trailing_parity_v2'
        new_dir = B/'backtests'/f'{NEW}{suffix}'
        old_candidates = {r['candidate_id'] for r in rows(old_dir/'normalized_candidates.csv')}
        new_candidates = {r['candidate_id'] for r in rows(new_dir/'normalized_candidates.csv')}
        assert old_candidates == new_candidates
        for mode in ['independent', 'portfolio']:
            old = {r['candidate_id']: r for r in rows(old_dir/f'{mode}_trades.csv')}
            new = {r['candidate_id']: r for r in rows(new_dir/f'{mode}_trades.csv')}
            old_stats, new_stats = statistics(list(old.values())), statistics(list(new.values()))
            assert not new_stats['wrong_side_initial_stop_candidate_ids']
            assert not new_stats['nonnegative_plain_sl_candidate_ids']
            comparisons[(suffix or '_no_filter')+'/'+mode] = dict(old=old_stats, new=new_stats)
            for cid, r in new.items():
                prior = old[cid]
                changed.append(dict(filter=suffix or '_no_filter', mode=mode, candidate_id=cid,
                    signal_ts=r['signal_ts_utc'], side=r['side'],
                    old_status=prior['entry_status'], new_status=r['entry_status'],
                    old_lifecycle=prior['lifecycle_class'], new_lifecycle=r['lifecycle_class'],
                    old_entry=prior['entry_fill_price'], new_entry=r['entry_fill_price'],
                    old_stop=prior['initial_stop_price'], new_stop=r['initial_stop_price'],
                    old_net=prior['net_pnl_usdc'], new_net=r['net_pnl_usdc'],
                    delta_net=float(r['net_pnl_usdc'])-float(prior['net_pnl_usdc'])))
    with (OUT/'trade_changes.csv').open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(changed[0]))
        writer.writeheader(); writer.writerows(changed)
    write_json(OUT/'metrics.json', comparisons)
    return comparisons


def audit_may4():
    candidates, _ = compile_candidates(B/'reviews', date_from='2026-05-04', date_to='2026-05-04',
        raw_archive_root=B/'raw_archive', candidate_groups=['PEAK_EMIT_BASELINE'])
    candidate = next(c for c in candidates if c.candidate_id == CID)
    manifest = json.loads((B/'backtests'/f'{OLD}_trailing_parity_v2/run_manifest.json').read_text())
    config = ReplayConfig(**manifest['resolved_config'])
    ref_old = load_feed(B/'source_archives/vps_refresh_2026-08-26/effective_feed_merged',
        date_from='2026-05-02', date_to='2026-05-05', quality_sidecar_root=B/'recovery_reports')
    ref_new = load_feed(B/'recovery_clock_v2_2026-09-08/effective_feed',
        date_from='2026-05-02', date_to='2026-05-05', quality_sidecar_root=B/'recovery_clock_v2_2026-09-08/quality')
    exec_new = load_feed(B/'execution_feed/btcusdc_spot_1m/daily',
        date_from='2026-05-02', date_to='2026-05-05', feed_role='official_spot_execution')
    exec_old = [replace(bar, ts=bar.ts-timedelta(minutes=1)) for bar in exec_new]
    cases = []
    for label, reference, execution in [
        ('old clocks (diagnostic only)', ref_old, exec_old),
        ('legacy timezone only (diagnostic only; spot close still future)', ref_new, exec_old),
        ('both clocks corrected', ref_new, exec_new),
    ]:
        plan = build_execution_plan(candidate, reference, config, execution_bars=execution)
        fill = find_entry_fill(execution, signal_ts=candidate.signal_ts_utc, plan=plan, config=config)
        case = dict(label=label, reference_close=plan.reference_feed_close_usdt,
                    execution_close=plan.execution_feed_close_usdc, ratio=plan.conversion_ratio,
                    planned_entry=plan.planned_entry_price, initial_stop=plan.initial_stop_price,
                    initial_swing_ts=plan.initial_swing_ts, initial_swing_price=plan.initial_swing_price_usdt,
                    fill_price=fill.entry_price, fill_bar_close_ts=execution[fill.entry_index].ts)
        try:
            result, _ = replay_candidate(candidate, execution, config, reference_bars=reference)
            case.update(lifecycle=result.lifecycle_class, net_usdc=result.net_pnl_usdc)
        except BacktestContractError as exc:
            case['contract_error'] = str(exc)
        cases.append(case)
    assert 'INITIAL_STOP_WRONG_SIDE_AFTER_FILL' in cases[0]['contract_error']
    assert cases[0]['fill_price'] == 78689.37 and cases[0]['initial_stop'] == 78375.16
    assert cases[-1]['fill_price'] == 78823.71 and cases[-1]['initial_stop'] == 79317.85
    assert cases[-1]['lifecycle'] == 'TP1_SL'
    source = B/'source_archives/vps_refresh_2026-08-31/server_state/trade_outcomes.jsonl'
    matches = [(n, json.loads(line)) for n, line in enumerate(source.read_text().splitlines(), 1)
               if 'EX_EN_1777889294' in line]
    assert len(matches) == 1
    line, outcome = matches[0]
    live = outcome['last_closed']
    assert live['entry_actual'] == 78814.69 and live['prices']['sl'] == 79923.07
    assert live['prices']['sl'] > live['entry_actual']
    record = dict(candidate_id=CID, signal_ts_utc=candidate.signal_ts_utc,
        signal_reference_price=candidate.signal_price, replay_cases=cases,
        live_source=dict(path=str(source), line=line, sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
        live_outcome=outcome)
    write_json(OUT/'may4_reconciliation.json', record)
    return record


if __name__ == '__main__':
    result = audit_baselines()
    audit_may4()
    for key, pair in result.items():
        r = pair['new']; print(key, 'fills', r['filled_count'], 'net', round(r['net_usdc'], 2),
            'PF', round(r['profit_factor'], 4), 'DD', round(r['max_drawdown_usdc'], 2))
    print('May4 old anomaly reproduced and rejected; corrected replay and live stop geometry verified.')
