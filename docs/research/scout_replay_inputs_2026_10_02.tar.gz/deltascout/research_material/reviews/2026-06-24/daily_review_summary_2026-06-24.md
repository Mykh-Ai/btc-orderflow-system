# Daily Review Summary 2026-06-24

- processed_date: 2026-06-24
- accepted_row_count: 3
- reject_row_count: 20
- interesting_reject_row_count: 16
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-06-24.csv
- reject_reason_summary_group_count: 5
- reject_counts_by_reason:
  - 3of3_fail: 2
  - direction_mismatch: 13
  - imb_band: 2
  - vwap_side: 3
- files_created:
  - accepted_event_context_2026-06-24.csv
  - reject_event_context_2026-06-24.csv
  - interesting_rejects_2026-06-24.csv
  - reject_reason_summary_2026-06-24.csv
  - daily_review_summary_2026-06-24.md
