# Daily Review Summary 2026-07-05

- processed_date: 2026-07-05
- accepted_row_count: 0
- reject_row_count: 21
- interesting_reject_row_count: 19
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-07-05.csv
- reject_reason_summary_group_count: 6
- reject_counts_by_reason:
  - 3of3_fail: 8
  - direction_mismatch: 9
  - vwap_side: 4
- files_created:
  - accepted_event_context_2026-07-05.csv
  - reject_event_context_2026-07-05.csv
  - interesting_rejects_2026-07-05.csv
  - reject_reason_summary_2026-07-05.csv
  - daily_review_summary_2026-07-05.md
