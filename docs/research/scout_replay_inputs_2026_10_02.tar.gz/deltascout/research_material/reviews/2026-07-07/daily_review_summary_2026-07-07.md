# Daily Review Summary 2026-07-07

- processed_date: 2026-07-07
- accepted_row_count: 0
- reject_row_count: 18
- interesting_reject_row_count: 16
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-07-07.csv
- reject_reason_summary_group_count: 5
- reject_counts_by_reason:
  - 3of3_fail: 4
  - direction_mismatch: 6
  - vwap_side: 8
- files_created:
  - accepted_event_context_2026-07-07.csv
  - reject_event_context_2026-07-07.csv
  - interesting_rejects_2026-07-07.csv
  - reject_reason_summary_2026-07-07.csv
  - daily_review_summary_2026-07-07.md
