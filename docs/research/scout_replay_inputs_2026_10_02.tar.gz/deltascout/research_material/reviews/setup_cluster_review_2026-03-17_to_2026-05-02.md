# Setup Cluster Review

scope: `2026-03-17_to_2026-05-02`
cluster_gap_minutes: `45`
cluster_rows: `50`

## Status Counts

- `candidate_setup`: 13
- `candidate_setup_with_reject_support`: 7
- `needs_more_evidence`: 11
- `reference_only`: 15
- `reject_followthrough_candidate`: 4

## Top Clusters

- `2026-03-23_long_c005` `2026-03-23 10:06:00` -> `2026-03-23 11:06:00` `long` `candidate_setup_with_reject_support` rows=6 move1000=6 dir60=2339.4 fav30=3004.9 fav60=2871.9; next: Promote to manual setup review with sequence and entry timing.
- `2026-03-21_short_c004` `2026-03-21 23:02:00` -> `2026-03-21 23:52:00` `short` `candidate_setup` rows=8 move1000=8 dir60=1892.9 fav30=1880.7 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-07_long_c025` `2026-04-07 21:39:00` -> `2026-04-07 23:20:00` `long` `candidate_setup_with_reject_support` rows=27 move1000=27 dir60=1789.8 fav30=1370.1 fav60=1627.4; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-16_short_c037` `2026-04-16 13:24:00` -> `2026-04-16 13:52:00` `short` `candidate_setup` rows=9 move1000=9 dir60=1342.7 fav30=1637.9 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-12_short_c032` `2026-04-12 00:50:00` -> `2026-04-12 01:35:00` `short` `candidate_setup` rows=6 move1000=6 dir60=1613.6 fav30=1535.5 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-03-31_long_c017` `2026-03-31 16:14:00` -> `2026-03-31 16:25:00` `long` `candidate_setup_with_reject_support` rows=5 move1000=5 dir60=1345.5 fav30=1135.6 fav60=1596.7; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-09_long_c028` `2026-04-09 14:38:00` -> `2026-04-09 15:14:00` `long` `candidate_setup_with_reject_support` rows=15 move1000=15 dir60=1484.8 fav30=1236.7 fav60=1231; next: Promote to manual setup review with sequence and entry timing.
- `2026-03-27_short_c010` `2026-03-27 09:56:00` -> `2026-03-27 10:38:00` `short` `candidate_setup` rows=8 move1000=8 dir60=1366.8 fav30=1474.1 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-22_long_c045` `2026-04-22 01:43:00` -> `2026-04-22 02:11:00` `long` `candidate_setup_with_reject_support` rows=6 move1000=6 dir60=1444.3 fav30=1082.1 fav60=1447.4; next: Promote to manual setup review with sequence and entry timing.
- `2026-03-29_short_c014` `2026-03-29 22:26:00` -> `2026-03-29 22:41:00` `short` `candidate_setup` rows=3 move1000=3 dir60=363 fav30=1399.7 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-14_long_c036` `2026-04-14 12:57:00` -> `2026-04-14 13:33:00` `long` `candidate_setup` rows=5 move1000=5 dir60=1394.5 fav30=1015.2 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-03-31_long_c016` `2026-03-31 00:36:00` -> `2026-03-31 01:16:00` `long` `candidate_setup` rows=5 move1000=5 dir60=1378 fav30=1208.6 fav60=0; next: Promote to manual setup review with sequence and entry timing.

## Promotion Rule

A cluster is not an `AI_EMIT` spec yet. Promote only after manual sequence review confirms repeatability, entry timing, lifecycle compatibility, and a realistic stop model.
