# Top Setup Cluster Quantitative Pre-Review

This is not manual validation. It is a first-pass calculation around representative entry proxies.
The review window includes pre-context and post-context; it is not the proposed trade window.

pre_context_minutes: `180`
post_context_minutes: `120`
nearby_accepted_lookahead_minutes: `180`

## Verdict Table

| cluster | direction | verdict | entry_quality | fav_after_rep | adverse_before_1000 | time_to_1000_min | lesson |
|---|---:|---|---|---:|---:|---:|---|
| `2026-03-23_long_c005` | `long` | `quant_candidate_with_reject_support` | `quant_fast_move_candidate` | `3004.9` | `102.5` | `15` | AI_EMIT research should test this process phase and separately inspect why current PEAK/reject logic filtered part of the move. |
| `2026-03-21_short_c004` | `short` | `quant_candidate_needs_visual_validation` | `quant_move_candidate` | `2042` | `15` | `51` | AI_EMIT research should treat this M2.6 sequence as a candidate grammar only after manual chart/sequence validation. |
| `2026-04-07_long_c025` | `long` | `quant_candidate_with_reject_support` | `quant_move_candidate` | `2083.4` | `234.5` | `28` | AI_EMIT research should test this process phase and separately inspect why current PEAK/reject logic filtered part of the move. |
| `2026-04-16_short_c037` | `short` | `quant_candidate_needs_visual_validation` | `quant_move_candidate` | `1637.9` | `86.4` | `24` | AI_EMIT research should treat this M2.6 sequence as a candidate grammar only after manual chart/sequence validation. |
| `2026-04-12_short_c032` | `short` | `quant_candidate_needs_visual_validation` | `quant_move_candidate` | `1717.6` | `117.8` | `50` | AI_EMIT research should treat this M2.6 sequence as a candidate grammar only after manual chart/sequence validation. |

## Cluster Notes

### 2026-03-23_long_c005

- Review window: `2026-03-23 07:06:00` to `2026-03-23 13:06:00`; cluster: `2026-03-23 10:06:00` to `2026-03-23 11:06:00`.
- Representative entry proxy: `2026-03-23 10:51:00` at `68463.1`.
- Pre-context directional move/delta: `962.9` / `-136.53`.
- Cluster directional move/delta: `1449` / `2879.215`.
- Post-context directional move/delta: `732.5` / `3968.542`.
- Candidate sources: `m2_6_chain_candidate:5; interesting_reject:1`; reject support: `true`.
- Nearby accepted PEAK: `none`.
- Risk note: Quantitative proxy only: adverse-before-hit is small, but entry trigger and stop model are not visually validated.

### 2026-03-21_short_c004

- Review window: `2026-03-21 20:02:00` to `2026-03-22 01:52:00`; cluster: `2026-03-21 23:02:00` to `2026-03-21 23:52:00`.
- Representative entry proxy: `2026-03-21 23:02:00` at `70231`.
- Pre-context directional move/delta: `135.6` / `-77.444`.
- Cluster directional move/delta: `901.1` / `-2385.787`.
- Post-context directional move/delta: `419.1` / `-2230.736`.
- Candidate sources: `m2_6_chain_candidate:8`; reject support: `false`.
- Nearby accepted PEAK: `none`.
- Risk note: Quantitative proxy only: adverse-before-hit is small, but entry trigger and stop model are not visually validated.

### 2026-04-07_long_c025

- Review window: `2026-04-07 18:39:00` to `2026-04-08 01:20:00`; cluster: `2026-04-07 21:39:00` to `2026-04-07 23:20:00`.
- Representative entry proxy: `2026-04-07 22:33:00` at `70660`.
- Pre-context directional move/delta: `1183.9` / `4856.833`.
- Cluster directional move/delta: `1884.7` / `6041.322`.
- Post-context directional move/delta: `-122.9` / `3840.722`.
- Candidate sources: `m2_6_chain_candidate:26; interesting_reject:1`; reject support: `true`.
- Nearby accepted PEAK: `none`.
- Risk note: Quantitative proxy only: adverse-before-hit is small, but entry trigger and stop model are not visually validated.

### 2026-04-16_short_c037

- Review window: `2026-04-16 10:24:00` to `2026-04-16 15:52:00`; cluster: `2026-04-16 13:24:00` to `2026-04-16 13:52:00`.
- Representative entry proxy: `2026-04-16 13:29:00` at `74894.7`.
- Pre-context directional move/delta: `-404.1` / `613.865`.
- Cluster directional move/delta: `552` / `-496.537`.
- Post-context directional move/delta: `-347.1` / `-136.247`.
- Candidate sources: `m2_6_chain_candidate:9`; reject support: `false`.
- Nearby accepted PEAK: `2026-04-16 15:53:00 short NO_TRADE/no_trade_missed_entry`.
- Risk note: Quantitative proxy only: adverse-before-hit is small, but entry trigger and stop model are not visually validated.

### 2026-04-12_short_c032

- Review window: `2026-04-11 21:50:00` to `2026-04-12 03:35:00`; cluster: `2026-04-12 00:50:00` to `2026-04-12 01:35:00`.
- Representative entry proxy: `2026-04-12 00:50:00` at `72976.6`.
- Pre-context directional move/delta: `403.2` / `-306.2`.
- Cluster directional move/delta: `416.8` / `-611.003`.
- Post-context directional move/delta: `929.8` / `-220.902`.
- Candidate sources: `m2_6_chain_candidate:6`; reject support: `false`.
- Nearby accepted PEAK: `2026-04-12 03:36:00 short SL/inferred_sl_missing_peak_link`.
- Risk note: Quantitative proxy only: adverse-before-hit is small, but entry trigger and stop model are not visually validated.

## Use

This is first-pass quantitative pre-review. It is not manual chart validation and not a live signal spec.
The next step is manual chart/sequence validation before any `AI_EMIT` setup spec draft.
