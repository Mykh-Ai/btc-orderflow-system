# Daily Review Summary 2026-08-10

- processed_date: 2026-08-10
- accepted_row_count: 1
- reject_row_count: 16
- interesting_reject_row_count: 11
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-08-10.csv
- reject_reason_summary_group_count: 4
- reject_counts_by_reason:
  - 3of3_fail: 1
  - direction_mismatch: 14
  - vwap_side: 1
- files_created:
  - accepted_event_context_2026-08-10.csv
  - reject_event_context_2026-08-10.csv
  - interesting_rejects_2026-08-10.csv
  - reject_reason_summary_2026-08-10.csv
  - daily_review_summary_2026-08-10.md
