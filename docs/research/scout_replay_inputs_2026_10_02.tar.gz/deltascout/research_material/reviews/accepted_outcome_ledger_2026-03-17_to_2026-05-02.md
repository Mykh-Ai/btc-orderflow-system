# Accepted Outcome Ledger: 2026-03-17 to 2026-05-02

Purpose: classify accepted `PEAK_EMIT` outcomes by lifecycle semantics, not by `close_reason` alone.

Sources:

- `reviews/accepted_outcome_ledger_2026-03-17_to_2026-05-02.csv`
- `reviews/*/accepted_event_context_*.csv`
- `reviews/*/close_outcomes_*.csv`

Machine-readable ledger:

- `accepted_outcome_ledger_2026-03-17_to_2026-05-02.csv`

This markdown file is the human explanation layer. The CSV is the canonical table for agents/LLMs.

## Classification Rule

`close_reason=SL` is not enough to classify the trade as a loss.

Use these fields together:

- `trade_lifecycle_state`
- `lifecycle_tp1_done`
- `lifecycle_tp2_done`
- `lifecycle_trail_active`
- `lifecycle_trail_sl_price`
- `join_status`

Buckets used here:

- `plain_loss_stop`: `SL` with `plain_sl` and no TP/trailing flags, or user-confirmed normal `SL` with no manual close.
- `protected_profit_trailing_stop`: `SL` with TP/trailing lifecycle fields.
- `tp1_reached_then_stop`: `SL` with TP1 reached but no confirmed trailing-profit context.
- `manual_confirmed_sl_result`: manual override with user-confirmed factual `SL` result; include in outcome evidence.
- `user_confirmed_sl_without_artifact_join`: accepted `PEAK_EMIT` exists and user confirmed the factual outcome was `SL`, but local close outcome/join fields are missing.
- `user_confirmed_sl_tp1_without_artifact_join`: accepted `PEAK_EMIT` exists and user confirmed factual result was stop-loss after TP1 / practical breakeven, but local close outcome/join fields are missing.
- `no_trade_missed_entry`: accepted `PEAK_EMIT` exists, but no trade was opened because price moved too fast and the bot missed the entry.
- `inferred_sl_missing_peak_link`: a close outcome row exists with matching date/side/entry context, but its `peak_ts` is blank and `join_status=missing`; treat as inferred until artifact join is repaired.
- `no_close_outcome_found`: no matching close outcome was found in the local artifacts.

## Summary

Accepted `PEAK_EMIT` rows in local corpus: `15`.

Outcome buckets:

| outcome_bucket | count |
|---|---:|
| `plain_loss_stop` | 4 |
| `protected_profit_trailing_stop` | 2 |
| `manual_confirmed_sl_result` | 1 |
| `user_confirmed_sl_without_artifact_join` | 1 |
| `user_confirmed_sl_tp1_without_artifact_join` | 1 |
| `no_trade_missed_entry` | 1 |
| `inferred_sl_missing_peak_link` | 5 |
| `no_close_outcome_found` | 0 |

Corrected interpretation:

- Do not describe accepted outcomes as "many SL losses".
- Confirmed pure losing stops are only rows where lifecycle confirms `plain_sl` or the user confirms normal `SL` with no manual close.
- The `2026-04-03 16:20` long accepted case closed on `2026-04-04` as `close_reason=SL`, but lifecycle shows `tp1_tp2_then_trailing_stop`; classify it as protected/profitable trailing-stop, not as a plain loss.
- `close_outcomes_2026-04-17.csv` shows `2026-04-17 10:49` reached TP1 and TP2 with trailing active before SL; classify it as protected/profitable trailing-stop.
- `close_outcomes_2026-04-21.csv` and `close_outcomes_2026-04-23.csv` show normal `SL` outcomes with no TP/trailing flags; classify them as `plain_loss_stop`.
- User confirmed `2026-04-05 14:34` `manual_override` is a factual `SL` result; include it in outcome evidence.
- User confirmed `2026-04-11 15:11` ended in stop-loss; classify it separately as `user_confirmed_sl_without_artifact_join` because the local close join is blank.
- User confirmed `2026-04-09 17:35` ended as `SL_TP1` / stop-loss after TP1; classify it as practical breakeven / TP1-then-stop, not as unknown.
- User confirmed `2026-04-16 15:53` did not become a trade: price moved down quickly and the bot missed the entry. This is a missed-entry / no-trade case, not an SL outcome.
- Five accepted rows have likely close outcomes in `close_outcomes_*.csv`, but those close rows have blank `peak_ts` and `join_status=missing`; these are coverage/join repair items, not necessarily unknown trade outcomes.
- After user clarification, there are currently no accepted rows with completely unknown outcome status in this ledger; remaining gaps are artifact enrichment/join repair issues.

## Ledger

| accepted_ts | side | price | join_status | close_reason | lifecycle flags | trade_lifecycle_state | outcome_bucket | ret_15m | ret_60m | regime context |
|---|---|---:|---|---|---|---|---|---:|---:|---|
| 2026-03-20 00:40:00 | short | 69822.435231 | joined | SL | tp1=False; tp2=False; trail=False | plain_sl | plain_loss_stop | 240.60 | 509.60 | c24=-8341.59; c180=-243.93; c60=526.42 |
| 2026-03-29 19:23:00 | short | 66232.738615 | joined | SL | tp1=False; tp2=False; trail=False | plain_sl | plain_loss_stop | 8.60 | 52.80 | c24=-2424.08; c180=-802.88; c60=68.99 |
| 2026-04-03 16:20:00 | long | 66788.022910 | joined | SL | tp1=True; tp2=True; trail=True | tp1_tp2_then_trailing_stop | protected_profit_trailing_stop | 51.30 | 14.00 | c24=93.57; c180=11.20; c60=174.55 |
| 2026-04-04 23:56:00 | long | 67451.712660 | missing | SL | inferred close row: 2026-04-05 01:00, LONG, entry=67451.49, missing peak_ts | plain_sl | inferred_sl_missing_peak_link | 24.90 | -79.70 | c24=562.46; c180=320.48; c60=-26.66 |
| 2026-04-05 14:34:00 | short | 66774.628139 | joined | SL | user-confirmed factual result | manual_override | manual_confirmed_sl_result | -187.00 | -249.00 | c24=339.55; c180=-283.17; c60=-125.07 |
| 2026-04-09 17:35:00 | long | 72028.453260 |  | SL_TP1 | user-confirmed stop-loss after TP1 / practical breakeven; local close join blank |  | user_confirmed_sl_tp1_without_artifact_join | -240.60 | 245.20 | c24=1046.12; c180=2936.47; c60=338.02 |
| 2026-04-11 15:11:00 | short | 72640.743647 |  | SL | user-confirmed SL; PEAK_EMIT exists; local close join blank |  | user_confirmed_sl_without_artifact_join | -31.10 | -15.40 | c24=2267.17; c180=-1150.06; c60=143.66 |
| 2026-04-12 03:36:00 | short | 72386.787216 |  | SL | inferred close row: 2026-04-13 15:03, SHORT, entry=72410.85, missing peak_ts |  | inferred_sl_missing_peak_link | 35.40 | -191.70 | c24=2907.12; c180=-305.92; c60=-105.25 |
| 2026-04-16 15:53:00 | short | 74030.858371 |  | NO_TRADE | user-confirmed no trade: price moved down quickly and bot missed entry; unrelated 2026-04-16 ENTRY_TIMEOUT_ABORT occurs before peak |  | no_trade_missed_entry | -207.70 | 671.30 | c24=2258.17; c180=-143.57; c60=558.26 |
| 2026-04-17 10:49:00 | long | 75585.543673 | window_match | SL | artifact-native accepted context after rebuild: tp1=True; tp2=True; trail=True; trail_sl=77509.0 |  | protected_profit_trailing_stop | 7.40 | -486.70 | c24=5049.38; c180=3413.82; c60=-936.09 |
| 2026-04-21 10:48:00 | long | 76739.504747 | window_match | SL | artifact-native accepted context after rebuild: tp1=False; tp2=False; trail=False |  | plain_loss_stop | 150.30 | 394.00 | c24=7829.54; c180=2229.04; c60=510.67 |
| 2026-04-22 04:12:00 | long | 76706.724118 |  | SL | inferred close row: 2026-04-22 16:45, LONG, entry=76743.52, missing peak_ts |  | inferred_sl_missing_peak_link | 62.00 | -44.90 | c24=2823.82; c180=2315.13; c60=-244.05 |
| 2026-04-23 10:45:00 | short | 77729.142780 | window_match | SL | artifact-native accepted context after rebuild: tp1=False; tp2=False; trail=False |  | plain_loss_stop | -12.30 | -354.80 | c24=3103.28; c180=-4475.85; c60=-3681.74 |
| 2026-04-26 07:13:00 | long | 78004.625597 |  | SL | inferred close row: 2026-04-26 22:34, LONG, entry=78039.81, missing peak_ts |  | inferred_sl_missing_peak_link | 0.00 | 0.00 | c24=0.00; c180=0.00; c60=0.00 |
| 2026-04-28 09:17:00 | short | 76474.423049 |  | SL | inferred close row: 2026-04-29 01:00, SHORT, entry=76477.91, missing peak_ts |  | inferred_sl_missing_peak_link | 0.00 | 0.00 | c24=0.00; c180=0.00; c60=0.00 |

## Open Verification Items

- `2026-04-11 15:11` is a real accepted `PEAK_EMIT` (`short`). User confirmed it ended in stop-loss, but the local artifact still lacks close outcome/join fields. Future artifact enrichment should encode this directly.
- `2026-04-09 17:35` is user-confirmed `SL_TP1`, but local artifacts lack close outcome/join fields. Future artifact enrichment should encode this directly.
- `2026-04-16 15:53` is user-confirmed `NO_TRADE`: the bot missed the entry after price moved down quickly. Future artifacts should distinguish no-trade missed entry from missing close outcome.
- `2026-04-17`, `2026-04-21`, and `2026-04-23` now have lifecycle fields propagated into `accepted_event_context_*` after the local builder fix and accepted-date rebuild.
- Repair missing `peak_ts` links for inferred close rows: `2026-04-04`, `2026-04-12`, `2026-04-22`, `2026-04-26`, and `2026-04-28`.
- `2026-04-26` and `2026-04-28` accepted rows have zeroed regime/return fields even though likely close outcomes exist. Treat their context fields as incomplete until source artifacts are verified.
- `close_outcomes_2026-04-16.csv` contains `ENTRY_TIMEOUT_ABORT` before the `2026-04-16 15:53` peak; do not map it to that accepted event without additional evidence.
