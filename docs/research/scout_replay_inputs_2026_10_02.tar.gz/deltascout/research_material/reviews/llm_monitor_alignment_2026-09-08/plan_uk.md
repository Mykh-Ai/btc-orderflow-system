# Executor LLM Trade Judge ↔ AiTrader Market Monitor: ознайомлення та план

Дата: 2026-09-08. Статус: read-only аудит коду, локальних журналів, комітів та
незакомічених змін. Цей документ — результат планування. Реалізація, запуски
моделі, нові кампанії, серверні команди, зміни даних і deployment не виконувалися.
Виконання — лише після окремої команди користувача.

## Висновок

Інтеграція існує і реально передавала JSON монітора в модель. Але цей JSON не є
повним актуальним дослідницьким монітором AiTrader. Його локальний структурний
контекст обмежений поточним UTC-днем, пам'ять класифікатора не передається,
деякі дефекти якості/одиниць не піднімаються до загального статусу, а контракт
промпта оцінює якість сигналу замість явного прогнозу фіналу за політикою Executor.

Перший практичний результат майбутньої роботи має бути відтворюваний, достатній
і своєчасний інформаційний пакет із перевірюваними фактами. Зміна формулювань
промпта сама по собі не виправить неповний ринковий стан. Готовність до торгових
дій потребуватиме окремої оцінки користі поверх V8 з витратами та портфелем.

## Де що знаходиться

| Частина | Перевірене розташування | Роль |
|---|---|---|
| Окремий Executor | `D:/Project_V/Executor` | Репозиторій гри, історія інтеграції, локальні журнали |
| Гра і промпт | `D:/Project_V/Executor/executor_mod/llm_trade_judge.py` | Evidence pack, виклик моделі, immutable первинний вердикт, scoring |
| JSON для LLM | `D:/Project_V/Executor/market_monitor/snapshot_builder.py` | Спеціальний in-memory snapshot builder |
| Дослідницький монітор | `D:/Project_V/Aitrader/market_monitor` | Структура, registry, hidden flow, market state, setup context, qualified H1 та replay-модулі |
| Візуальний snapshot | `D:/Project_V/Aitrader/market_monitor/trader_snapshot_builder.py` | HTML/SVG/PNG з артефактів; безпосередньо у LLM-запит не передається |
| Модульний V8 Executor | `D:/Project_V/btc-orderflow-system/executor/executor.py` і `executor_mod/` | Новіша інтеграція runtime; той самий файл LLM judge |
| Архів runtime | `deltascout/research_material/server_runtime_snapshot/2026-08-20/` | Локальний знімок серверних файлів, не поточний live inspection |
| Новіший локальний журнал гри | `deltascout/research_material/server_state/llm_trade_verdicts.jsonl` | 23 записи до 2026-08-18, збережені evidence packs |
| Старіший журнал гри | `D:/Project_V/Executor/server_journals/2026-06-29/llm_trade_verdicts.jsonl` | 14 записів до 2026-06-26; не використовувати як останній стан |

## Версії і локальні зміни

- Окремий Executor: гілка `v2.0`, HEAD `d51f644` від 2026-07-10:
  виправлення обрізаного JSON, default output budget 800 → 2000, повтор при
  невалідному JSON. Перед ним `b366e19` від 2026-06-29 додав repaired 37E
  `market_structure_state`; `71696ef` від 2026-06-10 — snapshot integration.
  У робочому дереві лише untracked `server_journals/`.
- AiTrader: гілка `codex/SHI_RESET_38G_live_like_bar_by_bar_state_replay_v0`,
  HEAD `f87cf33` від 2026-07-01, узгодження docs після 38S QC. Коміти 38S/38T,
  stage-gate replay і sequence stop anchoring переглянуті.
- Новіший стан AiTrader є також у незакомічених змінах: документи 39A від
  2026-07-02 та поправка `_target_reference_zone()` з тестами. Якщо немає
  цілі з правильного боку, повертається unresolved, замість fallback у
  неправильний бік. Це не commit-confirmed зміна.
- У монорепозиторії `219bfea` від 2026-09-05 синхронізував модульний V8;
  HEAD `dd02737` від 2026-09-06 стосується фільтрів DeltaScout/V8 parity.
  Попередні локальні research-зміни цієї задачі не чіпалися.
- Файл `llm_trade_judge.py` побайтово однаковий в окремому Executor,
  монорепозиторії та локальному runtime snapshot 20.08.
- Усі 33 `.py` файли `Executor/market_monitor` однакові з runtime snapshot
  20.08. У нинішньому AiTrader 48 `.py`: з Executor збігаються 21, відрізняються
  8 спільних, 19 існують тільки в AiTrader, 4 — тільки в Executor.
- Executor-only: `snapshot_builder.py`, `context_windows.py`,
  `accumulation_zones.py`, `significant_market_zones.py`. Тому сліпе копіювання
  всієї новішої теки AiTrader не є коректним оновленням інтеграції.
- Ще одна несумісність: Executor adapter передає liquidation columns, а
  поточний AiTrader adapter їх не має у вихідному контракті. Новіший файл
  не означає автоматично повніший LLM input.

Поточний сервер станом на 08.09 не опитувався. Наведені версії runtime
підтверджені локальним архівом 20.08; після нього могли бути зміни. Локальні
env-записи в `D:/Project_V/.executor.env` містять snapshot enabled і feed paths,
але не доводять поточні ефективні env/mounts контейнера.

## Фактичний зв'язок компонентів

1. DeltaScout PEAK стає `position.src_evt` в Executor.
2. Executor виконує вхід і виставляє захисні SL/TP.
3. Hook `EXITS_PLACED_V15` викликає `maybe_record_llm_pretrade_judge()`.
4. Evidence pack містить угоду, подію PEAK, summaries логів/aggregated feed та
   optional `market_monitor_snapshot`.
5. Весь pack серіалізується як текст JSON у промпт; графік PNG/HTML не додається.
6. Модель повертає SUPPORT / REJECT / UNCLEAR, confidence, setup_class,
   reason_codes, risk_flags, summary_ua. Запис зберігається у JSONL і може
   надсилатися в Telegram.
7. Після закриття гра порівнює первинний вердикт із durable lifecycle.
   Вердикт не змінює ордери; post-trade self-review та data-request loop
   описані як майбутні протоколи, реалізацію/новий durable review не знайдено.

Judge працює після відкриття і виставлення exits. Це не entry-veto до fill і не
моніторинг розвитку позиції. Первинний вердикт на trade_key дедуплікується.

## Що бачить модель

| Блок | Наявний зміст |
|---|---|
| Trade | Напрям, symbol, qty, planned/actual entry, SL/TP1/TP2, order ids, timestamps; іноді baseline balances |
| PEAK | `src_evt`, ціна, delta, volume, imbalance, VWAP/POC коли вони є, нормалізація часу |
| Контекст сигналів | PEAK за lookback 24h, до 5000 events, інтенсивність/відносна сила та розташування поточного сигналу |
| Aggregated context | Returns 15/60/240m, volatility 60m, High/Low 60/240m, buy/sell 60m, приблизні cumulative delta 24h і rolling VWAP |
| Monitor local | 15/60/240m price/volume/delta/OI/funding/liquidations та кількість використаних рядків |
| Monitor broad | 1/3/7/30d context, market-state summaries, значущі зони й liquidity buckets |
| Repaired 37E | `market_structure_state`, support/resistance, range/close position, candidate bias, OI context і evidence summary |
| Якість | Рядки RAW/RECOVERED_DEGRADED, окремі data_gaps/context_conflicts; повного readiness-контракту немає |

Важлива семантика промпта: `Judge only the trade signal quality at entry time`
та `Do not infer future outcome`. Поточна гра перевіряє оцінку сигналу через
майбутній результат, але не просить формальний прогноз terminal lifecycle.
Немає явного розподілу ймовірностей PLAIN_SL / TP1_SL / TP2-trailing, визначеного
горизонту, версії SL V8, формального R/витрат чи контракту очікуваної utility.

`analysis_cutoff_ts` переважно береться з PEAK; фактичний fill та order metadata
вже пізніші за нього. Це потрібно явно розділити на cutoff ринкових ознак,
момент виконання і момент рішення, а не називати весь пакет інформацією на
момент сигналу. Майбутні outcomes до поточного pack не додаються.

## Що підтверджують збережені запити

Новіший журнал: 23 записи від 13.05 до 18.08.2026. 19 успішних і 4 помилки JSON;
11 SUPPORT, 5 REJECT, 3 UNCLEAR. У 15 records є snapshot_v1, у 8 — repaired 37E.
Ці counts змішують версії і не є оцінкою точності або торгового PnL.

Конкретні контрольні записи:

- `EX_EN_1785025567`, cutoff `2026-07-26T00:26:00Z`: current feed — 27 хвилин.
  Local 60m і 240m отримують тільки 27 rows; `market_structure_state.status=ok`,
  загальні `evidence_pack.data_gaps=[]`. Є `rows_used/expected_minutes`, але
  немає зведеного запрету трактувати коротке вікно як повне.
- У цьому ж записі local `delta_pct=0.32005027`, state `delta_pct=32.005027`:
  та сама назва поля означає частку у першому блоці та відсотки у другому.
- `EX_EN_1787063409`, 18.08: `market_structure_state.status=partial`, resistance
  відсутній і вкладений gap присутній; загальні `evidence_pack.data_gaps=[]`.
- Порожній верхній gap-list не доводить достатність усіх вкладених даних.

## Проблеми і межі доказів

### Підтверджено кодом або журналом

1. **Обрізання локальної історії опівночі.** Current feed path розв'язується
   в один `YYYY-MM-DD.csv`; local windows, structure levels, registry і metrics
   state працюють з цим днем. Окремий broad feed має до 30 днів, але не
   заміняє історію локальної структури.
2. **Відсутність попередніх states у LLM bridge.** Виклик 37E classifier
   передає `previous_states=[]`. Наявність слова MEMORY у version id не
   означає використання пам'яті. Registry заново будується з current feed.
3. **Розрив із новим AiTrader.** LLM bridge не викликає setup_builder,
   qualified H1 sequence/stage gates або live-like state replay. Це не можна
   виправити самою згадкою цих термінів у промпті.
4. **Непослідовна якість.** Немає age/staleness gate від cutoff до останнього
   реального source timestamp; local windows — tail(N) рядків; вкладені gaps
   не збираються повністю; optional numeric поля можуть ставати нулями.
5. **Якість на рівні цілого файла.** Adapter позначає всі рядки дня degraded,
   якщо будь-де у файлі є synthetic. При історичному replay це також може
   залежати від synthetic рядка після cutoff, оскільки якість визначена до
   обрізання. Потрібні row/field-level flags і prefix-invariance перевірка.
6. **Одиниці та quote domains.** delta_pct має дві шкали. Snapshot отримує
   symbol BTCUSDC від угоди, хоча reference feed/PEAK переважно BTCUSDT; немає
   явного per-field price_symbol і conversion basis/time для геометрії V8.
7. **Старий recovery у AiTrader.** На `2026-05-04 10:08 UTC` локальний
   `AiTrader/feed_recovered` має Close 79636, тоді як виправлений UTC recovery
   DeltaScout — 78821; volume/delta також різні. Це та сама вже встановлена
   помилка clock join. Дані в AiTrader під час цього аудиту не змінювалися.
8. **Відтворюваність.** Журнал зберігає evidence pack/model, але не містить
   exact prompt text/hash/version, monitor code hash, input hashes або явної
   версії execution policy. Старі оцінки не слід об'єднувати з V8 без lineage.
9. **Синхронний виклик.** У модульному Executor success hook викликається
   безпосередньо; builder читає контекстну теку до фільтрації 30 днів, потім
   синхронно викликає HTTP з retries. Це потенційна затримка management loop;
   фактичну latency та її вплив на торгівлю тут не вимірювали.

### Потребує окремої перевірки в наступному етапі

- Поточні server/container hashes, env/mounts, останні фактичні запити,
  timestamps/запізнення source feed, помилки і latency після 18-20.08.
- H1/H4 завершеність: `aggregate_timeframe()` групує `floor(timeframe)` і не
  відсікає неповні групи, swing `created_at` бере початок confirming bucket.
  Потрібно перевірити підтвердження на частковій правій свічці та точний
  completed-minute контракт; з цього читання не робиться кількісна PnL-оцінка.
- Достатність повного level inventory, віку/валідності зон, sequence context
  та local-vs-broad precedence на контрольних випадках 39A.
- Якість прогнозів і PnL-utility. Наявність JSON, confidence або зелених
  історичних тестів не доводить можливість прибутково керувати позицією.

Локальний `AiTrader/feed` закінчується 28.06.2026; це межа локальної копії,
не доказ зупинки серверного collector. Recovery-period дослідження потребують
перебудови від правильної lineage, а не перезапису старих forensic артефактів.

## План після окремої команди

| Етап | Робота | Критерій завершення |
|---|---|---|
| 1. Runtime та lineage | Зняти read-only актуальні hashes/config/journals; зв'язати кожну угоду, pack, prompt, feed cutoff і версію SL/trailing | Для кожного audited verdict відомо, який код і які дані реально використано; локальний стан відрізняється від deployed явно |
| 2. Контракт даних | Узгодити UTC/closed-candle labels, USDT/USDC, однакові units, exact rolling windows, recovery v2 в окремій lineage, nullable unsupported fields і freshness/coverage gates | Midnight/пропуски/синтетика/майбутній suffix не дають хибного READY; raw originals і старі verdicts збережені |
| 3. Монітор та пам'ять | Переглянути й зафіксувати рішення 39A; окремими вузькими змінами узгодити level lifecycle/closed-H1 sequence та adapter для stateful snapshot; query full eligible inventory | Стан не скидається між днями/chunks; replay до cutoff відтворює той самий стан; raw penetration не названий confirmed reclaim; контрольні кейси 39A пройдені без підгонки під один |
| 4. Evidence/prompt v2 | Явно визначити задачу прогнозу фіналу за V8; передавати execution policy/R/geometry/cost assumptions, стан і зміни, аргументи за/проти; формалізувати uncertainty та unsupported evidence | Машинний output має перевірювані evidence references, визначені ймовірності/горизонт і причини; exact prompt/config/input збережені; confidence має визначену семантику |
| 5. Offline оцінка | Порівняти pack без monitor, старий monitor, новий monitor за фіксованою моделлю/промптом; не змішувати actual live outcomes з V8 counterfactual labels | Оцінені coverage, calibration/Brier, збережені переможці/уникнуті SL, PnL після витрат і нової зайнятості портфеля; окремо нова невикористана вибірка |
| 6. Практичний advisory | Після перевірки винести builder/LLM в окремий worker; незмінний вердикт на вході плюс окремі snapshots/оцінки розвитку; журналувати затримки/пропуски | LLM не блокує execution loop; кожна оцінка має свій as-of, стан позиції і версію; жодної автоматичної дії без окремо валідованої policy |

Пункт 3 плану — не дозвіл одночасно переносити всю 38/39-chain. Спочатку
узгоджується контракт і одна вузька зміна; run scripts не копіюються у runtime
як готові reusable modules. setup_builder лишається контекстним генератором,
38S 227 rows — discovery material, 38W1 — replay evidence, а не доведений edge.

Для майбутнього керування вже відкритою позицією потрібен окремий контракт:
remaining qty, актуальні SL/TP, TP1/TP2 status, realized/unrealized PnL у R,
останні зміни market state/level lifecycle і ціна виходу з витратами. Первинний
entry-verdict не переписується. Можливі checkpoints 5/15/30/60/240/1440 хв та
визначені структурні події; LLM не обов'язково викликати щохвилини.

Ранній вихід оцінюється як окрема політика дії. Наш попередній negative test
показав, що навіть логічний опис слабкості може втратити більше на переможцях,
ніж зекономити на SL. Точність класифікації фіналу не тотожна корисності виходу.

## Основні джерела

- [Executor LOG](D:/Project_V/Executor/LOG.md)
- [Game ADR](D:/Project_V/Executor/ADR-LLM-Trade-Judge-Game.md)
- [Evidence builder](D:/Project_V/Executor/executor_mod/llm_trade_judge.py:725)
- [Prompt](D:/Project_V/Executor/executor_mod/llm_trade_judge.py:1019)
- [LLM snapshot builder](D:/Project_V/Executor/market_monitor/snapshot_builder.py:25)
- [AiTrader current audit 39A](D:/Project_V/Aitrader/research/canonical/SHI_RESET_39A_MASTER_RESEARCH_TO_MONITOR_ALIGNMENT_AUDIT_2026_07_02.md)
- [39A promotion backlog](D:/Project_V/Aitrader/docs/SHI_MARKET_MONITOR_KNOWN_GAPS_AND_NEXT_PROMOTIONS.md)
- [Новіший локальний журнал](D:/Project_V/btc-orderflow-system/deltascout/research_material/server_state/llm_trade_verdicts.jsonl)
- [Виправлення recovery](D:/Project_V/btc-orderflow-system/deltascout/research_material/reviews/entry_anomaly_2026-05-04_audit_2026-09-08/report_uk.md)
