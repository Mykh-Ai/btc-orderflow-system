# Daily Review Summary 2026-06-28

- processed_date: 2026-06-28
- accepted_row_count: 0
- reject_row_count: 14
- interesting_reject_row_count: 12
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-06-28.csv
- reject_reason_summary_group_count: 5
- reject_counts_by_reason:
  - 3of3_fail: 1
  - direction_mismatch: 8
  - imb_band: 1
  - vwap_side: 4
- files_created:
  - accepted_event_context_2026-06-28.csv
  - reject_event_context_2026-06-28.csv
  - interesting_rejects_2026-06-28.csv
  - reject_reason_summary_2026-06-28.csv
  - daily_review_summary_2026-06-28.md
