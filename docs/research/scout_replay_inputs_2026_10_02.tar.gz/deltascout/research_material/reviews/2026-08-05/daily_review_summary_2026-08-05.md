# Daily Review Summary 2026-08-05

- processed_date: 2026-08-05
- accepted_row_count: 1
- reject_row_count: 16
- interesting_reject_row_count: 12
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-08-05.csv
- reject_reason_summary_group_count: 6
- reject_counts_by_reason:
  - 3of3_fail: 2
  - direction_mismatch: 7
  - imb_band: 3
  - vwap_side: 4
- files_created:
  - accepted_event_context_2026-08-05.csv
  - reject_event_context_2026-08-05.csv
  - interesting_rejects_2026-08-05.csv
  - reject_reason_summary_2026-08-05.csv
  - daily_review_summary_2026-08-05.md
