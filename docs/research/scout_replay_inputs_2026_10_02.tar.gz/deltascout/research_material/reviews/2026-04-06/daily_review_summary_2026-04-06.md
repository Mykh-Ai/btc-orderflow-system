# Daily Review Summary 2026-04-06

- processed_date: 2026-04-06
- accepted_row_count: 0
- reject_row_count: 19
- interesting_reject_row_count: 15
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-04-06.csv
- reject_reason_summary_group_count: 4
- reject_counts_by_reason:
  - direction_mismatch: 8
  - vwap_distance: 4
  - vwap_side: 7
- files_created:
  - accepted_event_context_2026-04-06.csv
  - reject_event_context_2026-04-06.csv
  - interesting_rejects_2026-04-06.csv
  - reject_reason_summary_2026-04-06.csv
  - daily_review_summary_2026-04-06.md
