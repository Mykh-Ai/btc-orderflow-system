# Move-First Research Windows

scope: `2026-03-17_to_2026-05-02`
move_threshold_usd: `1000`
forward_minutes: `60`
move_window_count: `108`

## Direction Counts

- `long`: 59
- `short`: 49

## Detector Coverage

- move windows with nearby accepted PEAK: `2`
- move windows with no nearby accepted PEAK: `106`
- move windows with nearby M2.6 candidate: `108`
- move windows with nearby reject row: `58`
- move windows with no nearby accepted/M2.6/reject annotation: `0`

## Top Move-First Windows

- `2026-04-07_long_mf065` `2026-04-07 21:28:00` -> `2026-04-07 23:20:00` `long` fav60=2363.3 best=2026-04-07 23:08:00 adverse=1.9 accepted=0 m2_6=49 rejects=1
- `2026-03-23_long_mf021` `2026-03-23 10:06:00` -> `2026-03-23 11:08:00` `long` fav60=3194.5 best=2026-03-23 10:56:00 adverse=4.3 accepted=0 m2_6=16 rejects=1
- `2026-04-17_long_mf090` `2026-04-17 12:09:00` -> `2026-04-17 13:08:00` `long` fav60=1435.3 best=2026-04-17 12:44:00 adverse=1.6 accepted=0 m2_6=31 rejects=1
- `2026-04-13_long_mf079` `2026-04-13 21:17:00` -> `2026-04-13 22:16:00` `long` fav60=1610 best=2026-04-13 21:32:00 adverse=1.6 accepted=0 m2_6=25 rejects=1
- `2026-04-09_long_mf071` `2026-04-09 14:22:00` -> `2026-04-09 15:20:00` `long` fav60=1648 best=2026-04-09 15:10:00 adverse=0.5 accepted=0 m2_6=25 rejects=1
- `2026-04-14_long_mf080` `2026-04-14 12:48:00` -> `2026-04-14 13:42:00` `long` fav60=1394.6 best=2026-04-14 12:58:00 adverse=1.8 accepted=0 m2_6=30 rejects=2
- `2026-03-31_long_mf049` `2026-03-31 15:43:00` -> `2026-03-31 16:40:00` `long` fav60=1690.9 best=2026-03-31 15:59:00 adverse=9.4 accepted=0 m2_6=24 rejects=1
- `2026-03-27_short_mf041` `2026-03-27 09:43:00` -> `2026-03-27 10:38:00` `short` fav60=1553.1 best=2026-03-27 10:34:00 adverse=6.3 accepted=0 m2_6=26 rejects=1
- `2026-03-21_short_mf017` `2026-03-21 22:53:00` -> `2026-03-21 23:54:00` `short` fav60=2030.3 best=2026-03-21 23:43:00 adverse=3.2 accepted=0 m2_6=14 rejects=1
- `2026-03-19_short_mf012` `2026-03-19 06:16:00` -> `2026-03-19 07:06:00` `short` fav60=1433.3 best=2026-03-19 06:19:00 adverse=0.1 accepted=0 m2_6=29 rejects=1
- `2026-04-17_long_mf091` `2026-04-17 13:27:00` -> `2026-04-17 13:51:00` `long` fav60=1622.4 best=2026-04-17 13:32:00 adverse=50.7 accepted=0 m2_6=30 rejects=0
- `2026-03-31_long_mf046` `2026-03-31 00:24:00` -> `2026-03-31 01:20:00` `long` fav60=1618.9 best=2026-03-31 01:12:00 adverse=4.7 accepted=0 m2_6=21 rejects=0
- `2026-04-12_short_mf075` `2026-04-12 00:37:00` -> `2026-04-12 01:35:00` `short` fav60=1835.4 best=2026-04-12 01:22:00 adverse=0.6 accepted=0 m2_6=14 rejects=1
- `2026-03-17_long_mf003` `2026-03-17 14:01:00` -> `2026-03-17 14:30:00` `long` fav60=1424 best=2026-03-17 14:26:00 adverse=22.7 accepted=0 m2_6=26 rejects=1
- `2026-04-16_short_mf088` `2026-04-16 12:55:00` -> `2026-04-16 13:52:00` `short` fav60=1691.3 best=2026-04-16 13:45:00 adverse=6 accepted=0 m2_6=16 rejects=0
- `2026-04-08_short_mf068` `2026-04-08 13:08:00` -> `2026-04-08 13:38:00` `short` fav60=1450.4 best=2026-04-08 13:34:00 adverse=38.8 accepted=0 m2_6=23 rejects=2
- `2026-03-23_short_mf026` `2026-03-23 11:09:00` -> `2026-03-23 11:44:00` `short` fav60=1657.8 best=2026-03-23 11:41:00 adverse=7 accepted=0 m2_6=21 rejects=0
- `2026-04-17_long_mf089` `2026-04-17 08:29:00` -> `2026-04-17 08:47:00` `long` fav60=1280.8 best=2026-04-17 08:47:00 adverse=3.8 accepted=0 m2_6=27 rejects=2
- `2026-03-18_short_mf007` `2026-03-18 10:31:00` -> `2026-03-18 11:29:00` `short` fav60=1336.5 best=2026-03-18 11:22:00 adverse=3.5 accepted=0 m2_6=22 rejects=0
- `2026-04-22_long_mf104` `2026-04-22 01:29:00` -> `2026-04-22 02:15:00` `long` fav60=1451.1 best=2026-04-22 02:14:00 adverse=0.1 accepted=0 m2_6=19 rejects=2

## Use

This artifact starts from market movement, not PEAK/M2.6/reject rows.
Use detector fields only to ask whether existing logic saw the move, missed it, or filtered it.
