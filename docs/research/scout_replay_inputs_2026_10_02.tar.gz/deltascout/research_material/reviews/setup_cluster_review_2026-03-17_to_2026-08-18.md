# Setup Cluster Review

scope: `2026-03-17_to_2026-08-18`
cluster_gap_minutes: `45`
cluster_rows: `101`

## Status Counts

- `candidate_setup`: 41
- `candidate_setup_with_reject_support`: 19
- `needs_more_evidence`: 20
- `reference_only`: 15
- `reject_followthrough_candidate`: 6

## Top Clusters

- `2026-03-23_long_c005` `2026-03-23 10:06:00` -> `2026-03-23 11:06:00` `long` `candidate_setup_with_reject_support` rows=6 move1000=6 dir60=2339.4 fav30=3004.9 fav60=2871.9; next: Promote to manual setup review with sequence and entry timing.
- `2026-06-25_short_c089` `2026-06-25 12:44:00` -> `2026-06-25 14:35:00` `short` `candidate_setup_with_reject_support` rows=26 move1000=26 dir60=2531.7 fav30=2961.1 fav60=1302; next: Promote to manual setup review with sequence and entry timing.
- `2026-06-07_long_c076` `2026-06-07 21:19:00` -> `2026-06-07 22:14:00` `long` `candidate_setup_with_reject_support` rows=6 move1000=6 dir60=1465.4 fav30=2560.4 fav60=2366.3; next: Promote to manual setup review with sequence and entry timing.
- `2026-06-04_short_c066` `2026-06-04 00:23:00` -> `2026-06-04 01:51:00` `short` `candidate_setup` rows=16 move1000=16 dir60=1933.6 fav30=1574.5 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-03-21_short_c004` `2026-03-21 23:02:00` -> `2026-03-21 23:52:00` `short` `candidate_setup` rows=8 move1000=8 dir60=1892.9 fav30=1880.7 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-06-04_long_c064` `2026-06-04 02:07:00` -> `2026-06-04 03:02:00` `long` `candidate_setup` rows=16 move1000=16 dir60=1823 fav30=1355.6 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-06-17_short_c081` `2026-06-17 18:46:00` -> `2026-06-17 19:16:00` `short` `candidate_setup` rows=10 move1000=10 dir60=1798.7 fav30=1342.4 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-07_long_c025` `2026-04-07 21:39:00` -> `2026-04-07 23:20:00` `long` `candidate_setup_with_reject_support` rows=27 move1000=27 dir60=1789.8 fav30=1370.1 fav60=1627.4; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-16_short_c037` `2026-04-16 13:24:00` -> `2026-04-16 13:52:00` `short` `candidate_setup` rows=9 move1000=9 dir60=1342.7 fav30=1637.9 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-05-15_short_c053` `2026-05-15 12:43:00` -> `2026-05-15 13:33:00` `short` `candidate_setup` rows=11 move1000=11 dir60=1628.6 fav30=1338 fav60=0; next: Promote to manual setup review with sequence and entry timing.
- `2026-06-05_short_c070` `2026-06-05 05:01:00` -> `2026-06-05 06:14:00` `short` `candidate_setup_with_reject_support` rows=22 move1000=22 dir60=1468.3 fav30=1626.4 fav60=1372.7; next: Promote to manual setup review with sequence and entry timing.
- `2026-04-12_short_c032` `2026-04-12 00:50:00` -> `2026-04-12 01:35:00` `short` `candidate_setup` rows=6 move1000=6 dir60=1613.6 fav30=1535.5 fav60=0; next: Promote to manual setup review with sequence and entry timing.

## Promotion Rule

A cluster is not an `AI_EMIT` spec yet. Promote only after manual sequence review confirms repeatability, entry timing, lifecycle compatibility, and a realistic stop model.
