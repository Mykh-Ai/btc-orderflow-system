# DeltaScout live runtime audit — 2026-08-31

Audit cutoff: 2026-08-31 16:39 UTC (18:39 Europe/Paris). VPS access was read-only. No runtime, configuration, order, or server file was changed.

## Runtime status

- Container `deltascout` was running continuously from 2026-08-20 20:05:35 UTC with restart count 0.
- Runtime loss-filter mode: `veto`.
- Runtime rule: `DS_PEAK_LOSS_AVOIDANCE_UNION_V1`.
- The deployed SHA-256 values of `delta_scout.py`, `loss_avoidance_policy.py`, and `loss_avoidance_runtime.py` exactly matched the corresponding local files.
- Targeted local verification: 45 passed, 1 skipped.

## Today's candidate funnel

- Raw DeltaScout candidates: 17.
- Accepted PEAK signals: 1.
- Rejected before PEAK admission: 16.
- Filter A/B vetoes: 0.
- Loss-filter evaluation errors or fail-open decisions: 0.

Core rejection counts:

- `direction_mismatch`: 7.
- `3of3_fail`: 4.
- `imb_band`: 2.
- `vwap_side`: 2.
- `vwap_distance`: 1.

The four `3of3_fail` candidates were:

- 06:12 local, SHORT: 1/3 passed; price and volume failed.
- 10:43 local, LONG: 2/3 passed; VWAP failed (`ALMOST_2OF3_VWAP_FAIL`).
- 10:57 local, LONG: 2/3 passed; volume failed (`ALMOST_2OF3_VOLUME_FAIL`).
- 16:42 local, LONG: 2/3 passed; VWAP failed (`ALMOST_2OF3_VWAP_FAIL`).

Current live ordering is core PEAK comparisons -> regime/gate checks -> A/B admission. Therefore these ALMOST candidates did not reach A/B evaluation. They were rejected by the original PEAK logic, not by A or B.

## A/B decision for the opened trade

Signal: 2026-08-31 10:58 Europe/Bratislava (08:58 UTC), LONG.

- Decision: `KEEP`.
- Effective action: `EMIT`.
- A: false. Same-side 24h peak percentile was 66.6667 with 12 observations; A blocks at percentile <= 50.
- B: false. OI change over 60 minutes was +217.66 and trusted; directional delta percentage over 240 minutes was 0.051956. B requires both falling OI and directional delta percentage below 0.06.
- Union A OR B: false.
- Feature status: `EXACT`.
- Evaluation time: 10.818 ms.
- Circuit breaker: closed.
- Fail-open reason: none.

There was exactly one true PEAK/filter decision from the container deployment on 2026-08-20 through this audit cutoff: today's `KEEP`. No `PEAK_LOSS_FILTER_REJECT` event was recorded in that interval.

## Trade lifecycle

- Trade key: `EX_EN_1788166698`.
- Pair: `BTCUSDC`.
- Opened: 08:58:20 UTC.
- Filled: entry 78,463.85, quantity 0.03823.
- Protective orders: SL 77,850.73; TP1 79,076.96; TP2 79,690.08.
- Closed by stop loss: 12:42:51 UTC.
- Lifecycle: `plain_sl`; TP1 false, TP2 false, trailing false.
- Gross realized PnL approximation: -23.4403422 USDC.
- Executor notification approximation: commission 4.478135487 USDC and net -27.918477687 USDC.
- Margin repayment completed; residual-debt cleanup reported clean.

An `LLM_TRADE_JUDGE_VERDICT=REJECT` appeared at 08:59:56 UTC, after the entry was filled and exit orders were already placed. It did not cancel the position; the position remained live until the stop loss.

## Journal and dataset status

- Canonical `trade_outcomes.jsonl` and `trade_execution_snapshots.jsonl` contain today's closed trade.
- The legacy `trade_pnl_ledger.csv` has not been updated since 2026-07-10 and does not contain today's trade.
- No server-side derived daily dataset for 2026-08-31 existed at the audit cutoff. A local close-outcome dataset and daily review package were rebuilt from the copied canonical sources.
- Local read-only snapshot: `source_archives/vps_refresh_2026-08-31/`.
- Snapshot provenance: `source_archives/vps_refresh_2026-08-31/vps_snapshot_manifest.json`.

## Offline timestamp warning

The live filter's audit record is timezone-aware and its enriched-feed lookup was `EXACT`. The generic `delta_analyzer` still parses source-local naive DeltaScout timestamps and UTC-naive enriched-feed timestamps as if they shared one clock. Consequently, context columns in the generated `events_context`/review CSVs can be shifted by two hours for this date. Candidate counts and raw rejection reasons are valid, but offline feed-context features must not be used for A/B conclusions until that timestamp contract is corrected. The A/B findings above come from the runtime audit record, not the affected offline join.
