# Daily Review Summary 2026-08-01

- processed_date: 2026-08-01
- accepted_row_count: 0
- reject_row_count: 19
- interesting_reject_row_count: 15
- accepted_with_close_outcomes: 0
- reject_reason_summary_created: reject_reason_summary_2026-08-01.csv
- reject_reason_summary_group_count: 6
- reject_counts_by_reason:
  - 3of3_fail: 3
  - direction_mismatch: 12
  - imb_band: 1
  - vwap_side: 3
- files_created:
  - accepted_event_context_2026-08-01.csv
  - reject_event_context_2026-08-01.csv
  - interesting_rejects_2026-08-01.csv
  - reject_reason_summary_2026-08-01.csv
  - daily_review_summary_2026-08-01.md
